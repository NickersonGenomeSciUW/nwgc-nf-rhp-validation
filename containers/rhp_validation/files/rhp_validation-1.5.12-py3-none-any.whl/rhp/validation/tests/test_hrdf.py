import json
from pathlib import Path
from shutil import copyfileobj
from typing import Any, Dict

import pytest
from click.testing import CliRunner

from rhp.cli import cli
from rhp.validation import CSVValidationError
from rhp.validation.constants import ClinicalAnalysisType
from rhp.validation.hrdf import validate_hdr_hrdf, validate_hrdf, validate_pgx_hrdf
from rhp.validation.tests.cases import (
    INVALID_HDR_HRDF_DATA,
    INVALID_PGX_HRDF_DATA,
    VALID_HRDF_DATA,
)
from rhp.validation.tests.util import get_test_file

CSV_TEST_FILENAME = "test.csv"
VALID_MESSAGE = "CSV validation succeeded!"


TEST_FILES_PACKAGE = "rhp.validation.tests.test_files.hrdf"

SUMMARY_END_MESSAGE = (
    "To see detailed cell-by-cell errors, run this script with --verbose."
)


@pytest.mark.parametrize(*VALID_HRDF_DATA)
def test_valid_hrdf(
    filename: str, clinical_analysis_type: ClinicalAnalysisType
) -> None:
    """Tests that a valid HRDF file is validated without raising."""
    validate_hrdf(
        file=get_test_file(TEST_FILES_PACKAGE, filename),
        clinical_analysis_type=clinical_analysis_type,
    )


@pytest.mark.parametrize(*INVALID_HDR_HRDF_DATA)
def test_invalid_hdr_hrdf(
    filename: str, expected_summary_verbose: str, expected_summary_concise: str
) -> None:
    """Tests that `validate_hdr_hrdf` raises the correct exception for an invalid HRDF
    file.
    """
    with pytest.raises(CSVValidationError) as error:
        validate_hdr_hrdf(get_test_file(TEST_FILES_PACKAGE, filename))
    assert error.value.summary(verbose=False) == expected_summary_concise
    assert error.value.summary(verbose=True) == expected_summary_verbose


@pytest.mark.parametrize(*INVALID_PGX_HRDF_DATA)
def test_invalid_pgx_hrdf(
    filename: str, expected_summary_verbose: str, expected_summary_concise: str
) -> None:
    """Tests that `validate_pgx_hrdf` raises the correct exception for an invalid HRDF
    file.
    """
    with pytest.raises(CSVValidationError) as error:
        validate_pgx_hrdf(get_test_file(TEST_FILES_PACKAGE, filename))
    assert error.value.summary(verbose=False) == expected_summary_concise
    assert error.value.summary(verbose=True) == expected_summary_verbose


@pytest.mark.parametrize(*VALID_HRDF_DATA)
def test_valid_hrdf_cli(
    filename: str, clinical_analysis_type: ClinicalAnalysisType
) -> None:
    runner = CliRunner()
    with runner.isolated_filesystem() as tmp_path:
        tmp_csv_path = Path(tmp_path) / CSV_TEST_FILENAME
        with open(tmp_csv_path, "w") as csv_file:
            copyfileobj(get_test_file(TEST_FILES_PACKAGE, filename), csv_file)

        result = runner.invoke(
            cli,
            [
                "validate",
                "hrdf",
                "--analysis-type",
                clinical_analysis_type.value,
                "--input-file",
                str(tmp_csv_path),
            ],
        )
        assert result.exit_code == 0
        assert result.output == f"{VALID_MESSAGE}\n"


@pytest.mark.parametrize(*INVALID_HDR_HRDF_DATA)
def test_invalid_hrdf_cli_verbose(
    filename: str, expected_summary_verbose: str, expected_summary_concise: str
) -> None:
    runner = CliRunner()
    with runner.isolated_filesystem() as tmp_path:
        tmp_csv_path = Path(tmp_path) / CSV_TEST_FILENAME
        with open(tmp_csv_path, "w") as csv_file:
            copyfileobj(get_test_file(TEST_FILES_PACKAGE, filename), csv_file)

        result = runner.invoke(
            cli,
            [
                "validate",
                "hrdf",
                "--verbose",
                "--analysis-type",
                ClinicalAnalysisType.HEREDITARY_DISEASE_RISK_V1.value,
                "--input-file",
                str(tmp_csv_path),
            ],
        )
        assert result.exit_code == 1
        assert result.output == f"{expected_summary_verbose}\n"


@pytest.mark.parametrize(*INVALID_HDR_HRDF_DATA)
def test_invalid_hrdf_cli_non_verbose(
    filename: str, expected_summary_verbose: str, expected_summary_concise: str
) -> None:
    runner = CliRunner()
    with runner.isolated_filesystem() as tmp_path:
        tmp_csv_path = Path(tmp_path) / CSV_TEST_FILENAME
        with open(tmp_csv_path, "w") as csv_file:
            copyfileobj(get_test_file(TEST_FILES_PACKAGE, filename), csv_file)

        result = runner.invoke(
            cli,
            [
                "validate",
                "hrdf",
                "--analysis-type",
                ClinicalAnalysisType.HEREDITARY_DISEASE_RISK_V1.value,
                "--input-file",
                str(tmp_csv_path),
            ],
        )
        assert result.exit_code == 1
        assert result.output == f"{expected_summary_concise}\n\n{SUMMARY_END_MESSAGE}\n"


@pytest.mark.parametrize(
    ("csv_file_path", "verbose", "expected_json"),
    (
        ("hdr/valid.csv", False, {"valid": True}),
        ("hdr/valid.csv", True, {"valid": True}),
        (
            "hdr/extra_column.csv",
            False,
            {
                "valid": False,
                "errors": [
                    {
                        "message": "Invalid columns:\n  Extra column: 'extra_column'",
                        "row_count": 1,
                    }
                ],
            },
        ),
        (
            "hdr/extra_column.csv",
            True,
            {
                "valid": False,
                "errors": [
                    {
                        "message": "Invalid columns:\n  Extra column: 'extra_column'",
                        "row": 0,
                    }
                ],
            },
        ),
        (
            "hdr/length_exceeded.csv",
            False,
            {
                "valid": False,
                "errors": [
                    {
                        "columns": ["classification_write_up"],
                        "message": "invalid value, maximum length is 1950",
                        "cell_count": 1,
                    }
                ],
            },
        ),
        (
            "hdr/length_exceeded.csv",
            True,
            {
                "valid": False,
                "errors": [
                    {
                        "columns": ["classification_write_up"],
                        "message": "invalid value, maximum length is 1950",
                        "row": 1,
                    }
                ],
            },
        ),
    ),
)
def test_hrdf_cli_json(
    csv_file_path: str, verbose: bool, expected_json: Dict[str, Any]
) -> None:
    runner = CliRunner()
    with runner.isolated_filesystem() as tmp_path:
        tmp_csv_path = Path(tmp_path) / CSV_TEST_FILENAME
        with open(tmp_csv_path, "w") as csv_file:
            copyfileobj(get_test_file(TEST_FILES_PACKAGE, csv_file_path), csv_file)

        args = [
            "validate",
            "hrdf",
            "--analysis-type",
            ClinicalAnalysisType.HEREDITARY_DISEASE_RISK_V1.value,
            "--input-file",
            str(tmp_csv_path),
            "--json",
        ]
        if verbose:
            args.append("--verbose")
        result = runner.invoke(cli, args)
        assert json.loads(result.output) == expected_json
