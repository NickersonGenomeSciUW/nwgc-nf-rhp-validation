from importlib import resources
from typing import TextIO


def get_test_file(package: str, file_path: str) -> TextIO:
    """Gets a test file that is part of a Python package. The result is a file object.

    Args:
        package: Python package
        file_path: The path to the file within the test_files subpackage.
    """
    file_path_components = file_path.split("/")
    if len(file_path_components) > 1:
        package = f"{package}.{'.'.join(file_path_components[:-1])}"
    return resources.open_text(package, file_path_components[-1])
