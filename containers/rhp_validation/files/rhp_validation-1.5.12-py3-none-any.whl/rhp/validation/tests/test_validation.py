from io import StringIO
from typing import Dict

import pytest

from rhp.validation import (
    CellValidationError,
    CellValidator,
    CSVFormat,
    CSVValidationError,
    RowValidationError,
    RowValidator,
    alleles_list_validator,
    base_string_validator,
    biobank_id_validator,
    chgvs_validator,
    clingen_variant_id_validator,
    date_validator,
    gene_and_disorder_validator,
    gene_and_transcript_validator,
    gene_diplotype_and_phenotype_validator,
    ghgvs_validator,
    hgvs_validator,
    length_validator,
    make_optional,
    number_validator,
    options_validator,
    phgvs_validator,
    ref_and_alt_validator,
    refseq_transcript_id_validator,
    regex_validator,
    required_validator,
    sample_id_validator,
    url_validator,
    validate_csv,
)
from rhp.validation.core import split_csv, validate_csv_row
from rhp.validation.validators import make_required


def simple_row_validator(data: Dict[str, str]) -> None:
    """A row validator that checks that data["a"] == data["b"]"""
    if not data["a"] == data["b"]:
        raise RowValidationError.from_errors(
            cell_errors=((("a", "b"), CellValidationError("expected a to equal b")),)
        )


@pytest.mark.parametrize(
    ("validator", "valid_input"),
    (
        (required_validator, "valid"),
        (options_validator(("A", "B", "C")), "A"),
        (options_validator(("A", "B", "C")), "B"),
        (options_validator(("A", "B", "C")), "C"),
        (date_validator, "2021-10-04"),
        (number_validator(), "5"),
        (number_validator(1), "5"),
        (number_validator(1, 10), "5"),
        (number_validator(1, 10, integer=True), "5"),
        (number_validator(1, 10, integer=False), "5.5"),
        (url_validator, "https://www.color.com"),
        (length_validator(5), "abcde"),
        (regex_validator(r"^abc$"), "abc"),
        (clingen_variant_id_validator, "CA12345"),
        (refseq_transcript_id_validator, "NM_001613.3"),
        (refseq_transcript_id_validator, "NM_001128425.1"),
        (biobank_id_validator, "A111111111"),
        (biobank_id_validator, "T111111111"),
        (sample_id_validator, "11111111111"),
        (base_string_validator, "ACTGTCTACTGTATC"),
        (ghgvs_validator, "chr17.GRCh37:g.41245513T>A"),
        (ghgvs_validator, "chrX.GRCh37:g.41245513T>A"),
        (ghgvs_validator, "chrx.GRCh37:g.41245513T>A"),
        (ghgvs_validator, "chrY.GRCh37:g.41245513T>A"),
        (ghgvs_validator, "chry.GRCh37:g.41245513T>A"),
        (chgvs_validator, "c.1187G>A"),
        (phgvs_validator, "p.Gly396Asp"),
        (alleles_list_validator, "[]"),
        (alleles_list_validator, "['C']"),
        (alleles_list_validator, "['C', 'T']"),
        (alleles_list_validator, "['C', 'T', 'G']"),
        (alleles_list_validator, "['AAACT', 'TTA', 'G']"),
    ),
)
def test_validators_valid_input(validator: CellValidator, valid_input: str) -> None:
    """Tests that cell validators accept valid input without raising."""
    validator(valid_input)


@pytest.mark.parametrize(
    ("validator", "invalid_input", "expected_error"),
    (
        (required_validator, "", "cannot be empty"),
        (
            options_validator(("A", "B", "C")),
            "D",
            "invalid value 'D', options are: A, B, C",
        ),
        (
            date_validator,
            "blah",
            "invalid value 'blah', expected date format YYYY-MM-DD",
        ),
        (
            date_validator,
            "2021-13-01",
            "invalid value '2021-13-01', expected date format YYYY-MM-DD",
        ),
        (
            date_validator,
            "2021-01-32",
            "invalid value '2021-01-32', expected date format YYYY-MM-DD",
        ),
        (number_validator(), "abc", "invalid value 'abc', expected a number"),
        (
            number_validator(integer=True),
            "abc",
            "invalid value 'abc', expected an integer",
        ),
        (
            number_validator(integer=True),
            "5.5",
            "invalid value '5.5', expected an integer",
        ),
        (
            number_validator(min_value=1),
            "0",
            "invalid value '0', expected a number greater than or equal to 1",
        ),
        (
            number_validator(max_value=0),
            "1",
            "invalid value '1', expected a number less than or equal to 0",
        ),
        (
            number_validator(min_value=1, integer=True),
            "0.5",
            "invalid value '0.5', expected an integer greater than or equal to 1",
        ),
        (
            number_validator(max_value=0, integer=True),
            "1",
            "invalid value '1', expected an integer less than or equal to 0",
        ),
        (
            number_validator(min_value=1, max_value=10),
            "-1",
            "invalid value '-1', expected a number between 1 and 10",
        ),
        (
            number_validator(min_value=1, max_value=10, integer=True),
            "-1",
            "invalid value '-1', expected an integer between 1 and 10",
        ),
        (url_validator, "blah", "invalid value 'blah', expected a URL"),
        (length_validator(5), "abcdef", "invalid value, maximum length is 5"),
        (regex_validator("^abc$"), "abcd", "invalid value 'abcd'"),
        (
            regex_validator(
                "^abc$", lambda value: f"invalid value '{value}', expected 'abc'"
            ),
            "abcd",
            "invalid value 'abcd', expected 'abc'",
        ),
        (
            clingen_variant_id_validator,
            "A12345",
            (
                "invalid ClinGen variant identifier 'A12345', expected CA followed by "
                "a number, e.g., CA12345"
            ),
        ),
        (
            clingen_variant_id_validator,
            "",
            (
                "invalid ClinGen variant identifier '', expected CA followed by a "
                "number, e.g., CA12345"
            ),
        ),
        (
            refseq_transcript_id_validator,
            "N_1234",
            (
                "invalid RefSeq transcript ID 'N_1234', expected an ID that looks like "
                "NM_123456.7"
            ),
        ),
        (
            refseq_transcript_id_validator,
            "",
            (
                "invalid RefSeq transcript ID '', expected an ID that looks like "
                "NM_123456.7"
            ),
        ),
        (
            biobank_id_validator,
            "A11111111",
            (
                "invalid Biobank ID 'A11111111', expected the letter A or T followed "
                "by a 9-digit number"
            ),
        ),
        (
            biobank_id_validator,
            "",
            (
                "invalid Biobank ID '', expected the letter A or T followed by a "
                "9-digit number"
            ),
        ),
        (
            sample_id_validator,
            "11111111",
            "invalid sample ID '11111111', expected an 11-digit number",
        ),
        (
            sample_id_validator,
            "",
            "invalid sample ID '', expected an 11-digit number",
        ),
        (
            base_string_validator,
            "ACTGTCTACBTGTATC",
            (
                "invalid base string 'ACTGTCTACBTGTATC', expected a string comprised "
                "of A, C, T, and G only"
            ),
        ),
        (
            base_string_validator,
            "",
            (
                "invalid base string '', expected a string comprised of A, C, T, and "
                "G only"
            ),
        ),
        (
            chgvs_validator,
            "",
            "invalid cHGVS nomenclature '', expected a value beginning with 'c.'",
        ),
        (
            chgvs_validator,
            "p.Gly396Asp",
            (
                "invalid cHGVS nomenclature 'p.Gly396Asp', expected a value beginning "
                "with 'c.'"
            ),
        ),
        (
            phgvs_validator,
            "",
            "invalid pHGVS nomenclature '', expected a value beginning with 'p.'",
        ),
        (
            phgvs_validator,
            "c.1187G>A",
            (
                "invalid pHGVS nomenclature 'c.1187G>A', expected a value beginning "
                "with 'p.'"
            ),
        ),
        (
            ghgvs_validator,
            "",
            (
                "invalid gHGVS nomenclature '', expected a value that looks like "
                "'chr17.GRCh37:g.41245513T>A'"
            ),
        ),
        (
            ghgvs_validator,
            "p.Gly396Asp",
            (
                "invalid gHGVS nomenclature 'p.Gly396Asp', expected a value that looks "
                "like 'chr17.GRCh37:g.41245513T>A'"
            ),
        ),
        (
            alleles_list_validator,
            "blah",
            'invalid allele list "blah", expected a Python-style list of strings '
            "comprised of A, C, T, and G only (e.g., ['C', 'TG'])",
        ),
        (
            alleles_list_validator,
            "1",
            'invalid allele list "1", expected a Python-style list of strings '
            "comprised of A, C, T, and G only (e.g., ['C', 'TG'])",
        ),
        (
            alleles_list_validator,
            "['A', 1]",
            "invalid allele list \"['A', 1]\", expected a Python-style list of strings "
            "comprised of A, C, T, and G only (e.g., ['C', 'TG'])",
        ),
        (
            alleles_list_validator,
            "['ACT', 'X']",
            "invalid allele list \"['ACT', 'X']\", expected a Python-style list of "
            "strings comprised of A, C, T, and G only (e.g., ['C', 'TG'])",
        ),
    ),
)
def test_validators_invalid_input(
    validator: CellValidator, invalid_input: str, expected_error: str
) -> None:
    """Tests that cell validators raise the correct exceptions when given invalid input."""
    with pytest.raises(CellValidationError) as error:
        validator(invalid_input)
    assert str(error.value) == expected_error


@pytest.mark.parametrize(
    "validator",
    (
        required_validator,
        options_validator(("A", "B", "C")),
        date_validator,
        number_validator(),
        url_validator,
        length_validator(5),
        regex_validator("^abc$"),
        clingen_variant_id_validator,
        refseq_transcript_id_validator,
    ),
)
def test_make_optional_make_required(validator: CellValidator) -> None:
    """Tests that:
    - Cell validators do not raise exceptions when given empty input and wrapped with
      `make_optional`.
    - Cell validators do raise exceptions when given empty input and wrapped with
      `make_required`.
    """
    optional_validator = make_optional(validator)
    optional_validator("")
    wrapped_required_validator = make_required(validator)
    with pytest.raises(CellValidationError) as error:
        wrapped_required_validator("")
    assert str(error.value) == "cannot be empty"


@pytest.mark.parametrize(
    ("validator", "input_dict"),
    (
        (simple_row_validator, {"a": "1", "b": "1"}),
        (simple_row_validator, {"a": "2", "b": "2"}),
        (
            gene_and_transcript_validator,
            {"gene_name": "MUTYH", "transcript": "NM_001128425.1"},
        ),
        (
            gene_and_disorder_validator,
            {"gene_name": "VHL", "reported_disorder": "VHL"},
        ),
        (
            ref_and_alt_validator,
            {"variant_ref": "ACTC", "variant_alt": "A"},
        ),
        (hgvs_validator, {"transcript": "NM_001128425.1", "chgvs": "c.1187G>A"}),
        (hgvs_validator, {"transcript": "NM_001128425.1", "phgvs": "p.Gly396Asp"}),
        (
            hgvs_validator,
            {"transcript": "NM_001128425.1", "ghgvs": "chr17.GRCh37:g.41245513T>A"},
        ),
        (
            hgvs_validator,
            {
                "transcript": "NM_001128425.1",
                "chgvs": "c.1187G>A",
                "phgvs": "p.Gly396Asp",
            },
        ),
        (
            hgvs_validator,
            {
                "transcript": "NM_001128425.1",
                "phgvs": "p.Gly396Asp",
                "ghgvs": "chr17.GRCh37:g.41245513T>A",
            },
        ),
        (
            hgvs_validator,
            {
                "transcript": "NM_001128425.1",
                "chgvs": "c.1187G>A",
                "ghgvs": "chr17.GRCh37:g.41245513T>A",
            },
        ),
        (
            hgvs_validator,
            {
                "transcript": "NM_001128425.1",
                "chgvs": "c.1187G>A",
                "phgvs": "p.Gly396Asp",
                "ghgvs": "chr17.GRCh37:g.41245513T>A",
            },
        ),
        (
            gene_diplotype_and_phenotype_validator,
            {
                "gene_name": "TPMT",
                "diplotype": "*1/*1",
                "phenotype": "normal metabolizer",
            },
        ),
        (
            gene_diplotype_and_phenotype_validator,
            {
                "gene_name": "NUDT15",
                "diplotype": "*1/*2",
                "phenotype": "intermediate metabolizer",
            },
        ),
    ),
)
def test_row_validators_valid_input(
    validator: RowValidator, input_dict: Dict[str, str]
) -> None:
    validator(input_dict)


@pytest.mark.parametrize(
    ("validator", "input_dict", "expected_error"),
    (
        (
            simple_row_validator,
            {"a": "1", "b": "2"},
            "[a, b] expected a to equal b",
        ),
        (
            gene_and_disorder_validator,
            {"gene_name": "MUTYH", "reported_disorder": "HCM"},
            (
                "[gene_name, reported_disorder] invalid disorder 'HCM' for gene MUTYH, "
                "accepted disorders are: MAP"
            ),
        ),
        (
            gene_and_transcript_validator,
            {"gene_name": "MUTYH", "transcript": "NM_000059.3"},
            (
                "[gene_name, transcript] invalid transcript 'NM_000059.3' for gene "
                "MUTYH, accepted transcripts are: NM_001128425"
            ),
        ),
        (
            ref_and_alt_validator,
            {"variant_ref": "ACTC", "variant_alt": "ACTC"},
            (
                "[variant_ref, variant_alt] expected ref and alt to differ, they are "
                "both 'ACTC'"
            ),
        ),
        (
            hgvs_validator,
            {"transcript": "NM_001128425.1", "chgvs": "c.blah"},
            (
                "[transcript, chgvs] cHGVS validation error: NM_001128425.1:c.blah: "
                "char 17: expected one of '(', '*', or a digit"
            ),
        ),
        (
            hgvs_validator,
            {"transcript": "NM_001128425.1", "phgvs": "p.blah"},
            (
                "[transcript, phgvs] pHGVS validation error: NM_001128425.1:p.blah: "
                "char 17: expected one of '(', '0', '=', '?', "
                "'Ala', 'Arg', 'Asn', 'Asp', 'Asx', 'Cys', 'Gln', 'Glu', 'Glx', "
                "'Gly', 'His', 'Ile', 'Leu', 'Lys', 'Met', 'Phe', 'Pro', 'Sec', "
                "'Ser', 'Ter', 'Thr', 'Trp', 'Tyr', 'Val', or 'Xaa'"
            ),
        ),
        (
            hgvs_validator,
            {"transcript": "NM_001128425.1", "ghgvs": "chr17.GRCh37:g.blah"},
            (
                "[transcript, ghgvs] gHGVS validation error: NC_000017.10:g.blah: char "
                "15: expected one of '(', '?', or a digit"
            ),
        ),
        (
            gene_diplotype_and_phenotype_validator,
            {"gene_name": "NUDT15", "diplotype": "*2/*1"},
            (
                "[diplotype, gene_name] invalid diplotype '*2/*1' for gene NUDT15, "
                "accepted diplotypes are: *1/*1, *1/*2, *1/*3, *2/*2, *2/*3, *3/*3, NA"
            ),
        ),
        (
            gene_diplotype_and_phenotype_validator,
            {
                "gene_name": "NUDT15",
                "diplotype": "*1/*2",
                "phenotype": "poor metabolizer",
            },
            (
                "[diplotype, gene_name, phenotype] invalid phenotype 'poor "
                "metabolizer' for gene NUDT15 and diplotype *1/*2, accepted phenotype "
                "is intermediate metabolizer"
            ),
        ),
    ),
)
def test_row_validators_invalid_input(
    validator: RowValidator, input_dict: Dict[str, str], expected_error: str
) -> None:
    with pytest.raises(RowValidationError) as error:
        validator(input_dict)

    assert str(error.value) == expected_error


@pytest.mark.parametrize(
    ("csv_format", "valid_row"),
    (
        (
            CSVFormat(
                columns=("a", "b"),
                cell_validators={
                    "a": required_validator,
                },
            ),
            {"a": "test", "b": ""},
        ),
        (
            CSVFormat(
                columns=tuple(str(key) for key in range(1000)),
                cell_validators={str(key): required_validator for key in range(1000)},
            ),
            {str(key): "test" for key in range(1000)},
        ),
        (
            CSVFormat(
                columns=("a", "b"),
                cell_validators={"a": required_validator},
                row_validators=(simple_row_validator,),
            ),
            {"a": "1", "b": "1"},
        ),
    ),
)
def test_validate_row_valid_input(
    csv_format: CSVFormat, valid_row: Dict[str, str]
) -> None:
    """Tests that `validate_csv_row` does not raise an exception for valid CSV rows."""
    validate_csv_row(valid_row, csv_format)


@pytest.mark.parametrize(
    ("csv_format", "invalid_row", "expected_error"),
    (
        (
            CSVFormat(
                columns=("a", "b"),
                cell_validators={
                    "a": required_validator,
                },
            ),
            {"a": "", "b": ""},
            "[a] cannot be empty",
        ),
        (
            CSVFormat(
                columns=("a", "b"),
                cell_validators={
                    "a": number_validator(),
                    "b": required_validator,
                },
            ),
            {"a": "abc", "b": ""},
            "[a] invalid value 'abc', expected a number\n[b] cannot be empty",
        ),
        (
            CSVFormat(
                columns=tuple(str(key) for key in range(1000)),
                cell_validators={str(key): required_validator for key in range(1000)},
            ),
            {str(key): "" if key % 2 == 0 else "test" for key in range(1000)},
            "\n".join(
                f"[{key}] cannot be empty" for key in range(1000) if key % 2 == 0
            ),
        ),
        (
            CSVFormat(
                columns=("a", "b"),
                cell_validators={"a": required_validator},
                row_validators=(simple_row_validator,),
            ),
            {"a": "", "b": "1"},
            "[a] cannot be empty\n[a, b] expected a to equal b",
        ),
    ),
)
def test_validate_row_invalid_input(
    csv_format: CSVFormat,
    invalid_row: Dict[str, str],
    expected_error: str,
) -> None:
    """Tests that `validate_csv_row` raises an exception for invalid CSV rows."""
    with pytest.raises(RowValidationError) as error:
        validate_csv_row(invalid_row, csv_format)
    assert str(error.value) == expected_error


@pytest.mark.parametrize(
    ("csv_format", "csv_data"),
    (
        (
            CSVFormat(
                columns=("a", "b"),
                cell_validators={
                    "a": required_validator,
                },
            ),
            "a,b\ntest,\n",
        ),
        (
            CSVFormat(
                columns=("a", "b"),
                cell_validators={
                    "a": required_validator,
                },
                row_validators=(simple_row_validator,),
            ),
            "a,b\ntest,test\n",
        ),
        (
            CSVFormat(
                columns=("a", "b"),
                cell_validators={"a": required_validator},
                overrides=(
                    (
                        lambda row: row["b"] == "override",
                        lambda column, cell_validator: (
                            make_optional(cell_validator)
                            if column == "a"
                            else cell_validator
                        ),
                    ),
                ),
            ),
            "a,b\n1,no override\n,override",
        ),
    ),
)
def test_validate_csv_valid_input(
    csv_format: CSVFormat,
    csv_data: str,
) -> None:
    """Tests that `validate_csv` does not raise an exception for a valid CSV file."""
    csv_buffer = StringIO(csv_data)
    validate_csv(csv_buffer, csv_format)


@pytest.mark.parametrize(
    ("csv_format", "csv_data", "expected_error"),
    (
        (
            CSVFormat(
                columns=("a", "b"),
                cell_validators={"a": required_validator},
            ),
            "a,b\n,test\n",
            "CSV validation failed:\n  [Row 1][a] cannot be empty",
        ),
        (
            CSVFormat(
                columns=("a", "b"),
                cell_validators={"a": required_validator},
            ),
            "a,b,c\n1,2,3\n",
            (
                "CSV validation failed:\n"
                "  [Row 0] Invalid columns:\n"
                "    Extra column: 'c'"
            ),
        ),
        (
            CSVFormat(columns=("a", "b"), cell_validators={"a": required_validator}),
            "a,b,c\n,2,3\n",
            (
                "CSV validation failed:\n"
                "  [Row 0] Invalid columns:\n"
                "    Extra column: 'c'\n"
                "  [Row 1][a] cannot be empty"
            ),
        ),
        (
            CSVFormat(columns=("a", "b"), cell_validators={"a": required_validator}),
            "a,c\n,\n",
            (
                "CSV validation failed:\n"
                "  [Row 0] Invalid columns:\n"
                "    Extra column: 'c'\n"
                "    Missing column: 'b'\n"
                "  [Row 1][a] cannot be empty"
            ),
        ),
        (
            CSVFormat(
                columns=("a",),
                cell_validators={
                    "a": required_validator,
                },
            ),
            "a,\n1,2\n",
            (
                "CSV validation failed:\n"
                "  [Row 1] unexpected value '2' with no column title"
            ),
        ),
        (
            CSVFormat(
                columns=("a",),
                cell_validators={
                    "a": required_validator,
                },
            ),
            "a,a,b,b\n1,2,3,4\n",
            (
                "CSV validation failed:\n"
                "  [Row 0] Invalid columns:\n"
                "    Duplicate column: 'a'\n"
                "    Duplicate column: 'b'\n"
                "    Extra column: 'b'"
            ),
        ),
        (
            CSVFormat(
                columns=("a", "b"),
                cell_validators={
                    "a": required_validator,
                },
                row_validators=(simple_row_validator,),
            ),
            "a,a,b,b\n1,2,3,4\n",
            (
                "CSV validation failed:\n"
                "  [Row 0] Invalid columns:\n"
                "    Duplicate column: 'a'\n"
                "    Duplicate column: 'b'\n"
                "  [Row 1][a, b] expected a to equal b"
            ),
        ),
        (
            CSVFormat(
                columns=("a", "b"),
                cell_validators={"a": required_validator},
                overrides=(
                    (
                        lambda row: row["b"] == "override",
                        lambda column, cell_validator: (
                            make_optional(cell_validator)
                            if column == "a"
                            else cell_validator
                        ),
                    ),
                ),
            ),
            "a,b\n,no override\n,override",
            ("CSV validation failed:\n  [Row 1][a] cannot be empty"),
        ),
    ),
)
def test_validate_csv_invalid_input(
    csv_format: CSVFormat,
    csv_data: str,
    expected_error: str,
) -> None:
    """Tests that `validate_csv` raises the correct exception for an invalid CSV file."""
    csv_buffer = StringIO(csv_data)

    with pytest.raises(CSVValidationError) as error:
        validate_csv(csv_buffer, csv_format)

    assert str(error.value) == expected_error


@pytest.mark.parametrize(
    ("csv_format", "csv_data", "expected_valid_file", "expected_invalid_file"),
    (
        (
            CSVFormat(
                columns=("a", "b", "c"),
                cell_validators={
                    "a": required_validator,
                    "b": date_validator,
                    "c": number_validator(),
                },
            ),
            "a,b,c\n1,2021-12-15,1\n,2021-12-15,1\n1,2021-13-15,1\n1,2021-12-15,abc\n",
            "a,b,c\n1,2021-12-15,1\n",
            "a,b,c\n,2021-12-15,1\n1,2021-13-15,1\n1,2021-12-15,abc\n",
        ),
        (
            CSVFormat(
                columns=("a", "b", "c"),
                cell_validators={
                    "a": required_validator,
                    "b": date_validator,
                    "c": number_validator(),
                },
            ),
            "a,b\n1,2021-12-15\n,2021-12-15\n1,2021-13-15\n1,2021-12-15\n",
            "",
            "a,b\n1,2021-12-15\n,2021-12-15\n1,2021-13-15\n1,2021-12-15\n",
        ),
        (
            CSVFormat(
                columns=("a", "b", "c"),
                cell_validators={
                    "a": required_validator,
                    "b": date_validator,
                    "c": number_validator(),
                },
            ),
            "a,b,c\n1,2021-12-15,1\n2,2021-12-15,1\n1,2021-12-15,1\n1,2021-12-15,2\n",
            "a,b,c\n1,2021-12-15,1\n2,2021-12-15,1\n1,2021-12-15,1\n1,2021-12-15,2\n",
            "",
        ),
    ),
)
def test_split(
    csv_format: CSVFormat,
    csv_data: str,
    expected_valid_file: str,
    expected_invalid_file: str,
) -> None:
    """Tests that `split_csv` successfully partitions valid and invalid rows from a
    CSV into valid and invalid CSVs.
    """
    input_file = StringIO(csv_data)
    valid_file = StringIO(newline="")
    invalid_file = StringIO(newline="")
    split_csv(
        csv_file=input_file,
        csv_format=csv_format,
        valid_output_file=valid_file,
        invalid_output_file=invalid_file,
    )
    assert valid_file.getvalue() == expected_valid_file
    assert invalid_file.getvalue() == expected_invalid_file


def test_utf8_sig_tolerance() -> None:
    """Tests that `validate_csv` tolerates the utf-8-sig encoding sometimes produced by MS
    Excel.
    """
    csv_format = CSVFormat(columns=("a",))
    csv_data = "\ufeffa\n1\n"
    validate_csv(StringIO(csv_data), csv_format)
