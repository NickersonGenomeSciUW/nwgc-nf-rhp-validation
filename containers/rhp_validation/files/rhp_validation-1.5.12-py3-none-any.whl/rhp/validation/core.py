import csv
from collections import defaultdict
from shutil import copyfileobj
from textwrap import indent
from typing import (
    Any,
    Callable,
    DefaultDict,
    Dict,
    Iterable,
    List,
    Mapping,
    Optional,
    Sequence,
    TextIO,
    Tuple,
    cast,
)

ERROR_INDENT_SIZE = 2
CellValidator = Callable[[str], None]
RowValidator = Callable[[Dict[str, str]], None]
RowPredicate = Callable[[Dict[str, str]], bool]
OverrideFn = Callable[[str, CellValidator], CellValidator]


class CellValidationError(Exception):
    """An error when validating a CSV cell."""


class RowValidationError(Exception):
    """An error when validating a CSV row. Stores detailed information about validation
    errors in each cell in the row.
    """

    def __init__(
        self,
        message: Optional[str] = None,
        cell_errors: Optional[
            Sequence[Tuple[Tuple[str, ...], CellValidationError]]
        ] = None,
    ) -> None:
        # For row-level errors we just use a message. For sets of cell-level errors we
        # use a list of cell errors. We only want one of these, hence the XOR (^).
        assert bool(message) ^ bool(cell_errors)
        self.cell_errors = cell_errors
        self.message = message or self.summary()
        super().__init__(self.message)

    @classmethod
    def from_errors(
        cls,
        cell_errors: Optional[
            Sequence[Tuple[Tuple[str, ...], CellValidationError]]
        ] = None,
        row_errors: Optional[Sequence["RowValidationError"]] = None,
    ) -> "RowValidationError":
        all_cell_errors: List[Tuple[Tuple[str, ...], CellValidationError]] = []
        if cell_errors:
            all_cell_errors += cell_errors
        if row_errors:
            for row_error in row_errors:
                if row_error.cell_errors:
                    all_cell_errors += row_error.cell_errors

        return cls(cell_errors=all_cell_errors)

    def summary(self) -> str:
        """A summary of the error(s) encountered in the row."""
        message_rows = []
        for error_dict in self.as_dicts():
            message_row = ""
            columns = error_dict["columns"]
            if columns:
                message_row += f"[{', '.join(columns)}] "
            message_row += error_dict["message"]
            message_rows.append(message_row)
        return "\n".join(message_rows)

    def as_dicts(self) -> List[Dict[str, Any]]:
        """A list of dictionary representations of the error(s) encountered in the row.
        Used to produce JSON output.
        """
        if self.cell_errors:
            return [
                {"columns": columns, "message": str(error)}
                for columns, error in self.cell_errors
            ]
        return [{"message": self.message}]


class CSVValidationError(Exception):
    """An error when validating a CSV file. Stores detailed information about validation
    errors in each row (and each cell in each row) in the file.
    """

    def __init__(
        self,
        row_errors: Optional[Sequence[Tuple[int, RowValidationError]]] = None,
    ) -> None:
        self.row_errors = row_errors
        self.message = self.summary(verbose=True)
        super().__init__(self.message)

    @classmethod
    def from_row_errors(
        cls, row_errors: Sequence[Tuple[int, RowValidationError]]
    ) -> "CSVValidationError":
        return cls(row_errors=row_errors)

    def summary(self, verbose: bool = False) -> str:
        """A summary of the validation errors encountered.

        Args:
            verbose:
                Whether the summary should be verbose. If `True`, the summary will be a
                detailed cell-by-cell report of all errors. If `False`, the summary will
                attempt to de-deduplicate errors that occur over multiple cells.
        """
        # To keep the error collection logic the same whether or not --json is used,
        # reuse self.as_dict() for the human-readable summary
        summary_dict = self.as_dict(verbose=verbose)
        summary_message = cast(Optional[str], summary_dict.get("message"))
        if summary_message:
            return summary_message

        indentation = " " * ERROR_INDENT_SIZE
        message_rows = ["CSV validation failed:"]
        for error in summary_dict["errors"]:
            columns = error.get("columns")
            row = error.get("row")
            row_count = error.get("row_count")
            cell_count = error.get("cell_count")
            message = error["message"]

            message_row = ""
            if row is not None:
                message_row += f"[Row {row}]"
            if columns:
                message_row += f"[{', '.join(columns)}]"
            if row_count:
                message_row += f"[{row_count} row{'s' if row_count > 1 else ''}]"
            if cell_count:
                message_row += f"[{cell_count} cell{'s' if cell_count > 1 else ''}]"
            message_row += f" {message}"
            message_rows.append(indent(message_row, indentation))
        return "\n".join(message_rows)

    def as_dict(self, verbose: bool = False) -> Dict[str, Any]:
        """A dictionary representation of the validation errors encountered. Used to
        produce JSON output.

        Args:
            verbose:
                Whether the dict representation should be verbose. If `True`, the
                representation will be a detailed cell-by-cell report of all errors. If
                `False`, the representation will attempt to de-deduplicate errors that
                occur over multiple cells.
        """
        result = {"valid": False}
        if not self.row_errors:
            return {**result, "message": self.message}

        # Add row number to errors
        errors: List[Dict[str, Any]] = []
        for row_num, row_error in self.row_errors:
            for row_dict in row_error.as_dicts():
                errors.append({**row_dict, "row": row_num})

        # Sort errors by row number, columns, message
        errors = sorted(
            errors,
            key=lambda error: (error["row"], error.get("columns"), error["message"]),
        )

        if verbose:
            return {**result, "errors": errors}

        # In non-verbose mode, de-duplicate errors over multiple rows with the same
        # affected columns and message
        errors_grouped: DefaultDict[Tuple[Tuple[str, ...], str], int] = defaultdict(int)
        for error in errors:
            errors_grouped[error.get("columns") or (), error["message"]] += 1
        deduped_errors = []
        for (columns, message), count in sorted(errors_grouped.items()):
            # Column-specific errors have one column and a cell_count; all other errors
            # have 0 or >1 columns and a row_count
            if len(columns) == 1:
                deduped_errors.append(
                    {"columns": columns, "message": message, "cell_count": count}
                )
            else:
                error = {"message": message, "row_count": count}
                if len(columns) > 0:
                    error["columns"] = columns
                deduped_errors.append(error)
        return {**result, "errors": deduped_errors}


class CSVFormat:
    """An expected format (schema) for a CSV file.

    Args:
        columns: The list of expected columns for the CSV format.
        cell_validators:
            A mapping of column names to validator functions for those columns.
        row_validators:
            A sequence of row validator functions. Row validator functions receive an
            entire row as a dictionary and raise `RowValidationError` if the row is
            invalid.
        overrides:
            A sequence of overrides to apply to validation of rows. Each override has a
            predicate and an override function. If the predicate returns `True` on a
            row, the cell validators will be mapped to new cell validators using the
            override function before being used to validate the row. Overrides will be
            applied in order and it is possible for a cell validator to be overridden
            multiple times.
    """

    def __init__(
        self,
        columns: Iterable[str],
        cell_validators: Optional[Mapping[str, CellValidator]] = None,
        row_validators: Optional[Iterable[RowValidator]] = None,
        overrides: Optional[Iterable[Tuple[RowPredicate, OverrideFn]]] = None,
    ) -> None:
        self.columns = tuple(columns)
        self.cell_validators: Dict[str, CellValidator] = dict(cell_validators or {})
        self.row_validators: Tuple[RowValidator, ...] = tuple(row_validators or ())
        self.overrides: Tuple[Tuple[RowPredicate, OverrideFn], ...] = tuple(
            overrides or ()
        )


def validate_csv(csv_file: TextIO, csv_format: CSVFormat) -> None:
    """Validates a CSV file using a given CSV format. Raises a `CSVValidationError` if
    validation errors are encountered.

    Args:
        csv_file: The CSV file (any file-like object) to validate.
        csv_format: The CSV format to validate against.
    """
    csv_reader = csv.reader(csv_file)
    row_errors: List[Tuple[int, RowValidationError]] = []
    valid_csv_columns: Dict[str, int] = {}
    for row_num, row in enumerate(csv_reader):
        try:
            if row_num == 0:
                validate_csv_column_names(
                    row,
                    csv_format.columns,
                )
            else:
                validate_csv_row(
                    {
                        column_name: row[column_index]
                        for column_name, column_index in valid_csv_columns.items()
                    },
                    csv_format,
                )
        except RowValidationError as row_error:
            row_errors.append((row_num, row_error))
        finally:
            if row_num == 0:
                for column_index, column_name in enumerate(row):
                    if (
                        column_name in csv_format.columns
                        # MS Excel sometimes adds blank columns - we can tolerate this
                        or column_name == ""
                    ):
                        valid_csv_columns[column_name] = column_index
                    elif column_index == 0:
                        # MS Excel sometimes adds a byte-order marker (BOM) at the start
                        # of the file due to utf-8-sig encoding - we can tolerate this
                        sig_decoded_column = column_name.encode("utf-8").decode(
                            "utf-8-sig"
                        )
                        if sig_decoded_column in csv_format.columns:
                            valid_csv_columns[sig_decoded_column] = column_index

    if len(row_errors) > 0:
        raise CSVValidationError.from_row_errors(row_errors)


def split_invalid_csv(
    csv_file: TextIO,
    row_errors: Sequence[Tuple[int, RowValidationError]],
    valid_output_file: TextIO,
    invalid_output_file: TextIO,
) -> None:
    """Given a CSV file known to be invalid, partitions the rows in the CSV into "valid"
    and "invalid" output files.

    Args:
        csv_file: The CSV input file (any file-like object).
        row_errors:
            The CSV row errors that occurred as tuples of row number and validation
            error.
        valid_output_file: The valid output file (any file-like object).
        invalid_output_file: The invalid output file (any file-like object).
    """
    # Seek to the beginning of the input file - validation probably put the cursor at
    # the end
    csv_file.seek(0)

    # Filter valid and invalid rows into separate files
    valid_writer = csv.writer(
        valid_output_file, dialect="unix", quoting=csv.QUOTE_MINIMAL
    )
    invalid_writer = csv.writer(
        invalid_output_file, dialect="unix", quoting=csv.QUOTE_MINIMAL
    )
    invalid_row_nums = {row_error[0] for row_error in row_errors}
    for row_num, row in enumerate(csv.reader(csv_file)):
        if row_num == 0:
            # Copy the column headings into both files
            valid_writer.writerow(row)
            invalid_writer.writerow(row)
        elif row_num in invalid_row_nums:
            # Write the row to the invalid output if it didn't validate
            invalid_writer.writerow(row)
        else:
            # Write the row to the valid output if it validated
            valid_writer.writerow(row)


def split_csv(
    csv_file: TextIO,
    csv_format: CSVFormat,
    valid_output_file: TextIO,
    invalid_output_file: TextIO,
) -> None:
    """Given a CSV input file and a CSV format, partitions the rows in the CSV into "valid"
    and "invalid" output files. If the input file is valid, the invalid output file will
    be empty. If the input file has invalid columns, the valid output file will be
    empty.

    Args:
        csv_file: The CSV input file (any file-like object).
        csv_format: The CSV format to validate against.
        valid_output_file: The valid output file (any file-like object).
        invalid_output_file: The invalid output file (any file-like object).
    """
    try:
        # Validate the CSV
        validate_csv(csv_file, csv_format)
    except CSVValidationError as validation_error:
        # If there are errors in the first row (the column headings), then treat the
        # whole file as invalid and copy it to the invalid output
        if not validation_error.row_errors or any(
            row_error[0] == 0 for row_error in validation_error.row_errors
        ):
            # Seek to the beginning of the input file - validation probably put the
            # cursor at the end
            csv_file.seek(0)
            copyfileobj(csv_file, invalid_output_file)
        else:
            split_invalid_csv(
                csv_file=csv_file,
                row_errors=validation_error.row_errors,
                valid_output_file=valid_output_file,
                invalid_output_file=invalid_output_file,
            )
    else:
        # Seek to the beginning of the input file - validation probably put the
        # cursor at the end
        csv_file.seek(0)
        # If there are no errors, copy the whole file to the valid output
        copyfileobj(csv_file, valid_output_file)


def validate_csv_column_names(
    column_names: Iterable[str], expected_column_names: Iterable[str]
) -> None:
    """Validates some column names from a CSV file against expected column names. Raises a
    `RowValidationError` with details about the differences if the column names do not
    match.

    Args:
        column_names: The column names seen in the CSV file.
        expected_column_names: The column names expected (e.g., from a `CSVFormat`).
    """
    ordered_columns = list(column_names)
    columns = set(ordered_columns)
    expected_columns = set(expected_column_names)
    extra_columns = columns.difference(expected_columns)
    missing_columns = expected_columns.difference(columns)
    duplicate_columns = {
        column_name
        for column_name in column_names
        if list(column_names).count(column_name) > 1
    }

    # MS Excel sometimes adds blank columns - we can tolerate this
    if "" in extra_columns:
        extra_columns.remove("")
    if "" in duplicate_columns:
        duplicate_columns.remove("")

    # MS Excel sometimes adds an byte-order marker (BOM) at the start of the file due to
    # utf-8-sig encoding - we can tolerate this
    if len(ordered_columns) > 0 and ordered_columns[0] in extra_columns:
        sig_decoded_column = ordered_columns[0].encode("utf-8").decode("utf-8-sig")
        if sig_decoded_column in missing_columns:
            extra_columns.remove(ordered_columns[0])
            missing_columns.remove(sig_decoded_column)

    if len(extra_columns) > 0 or len(missing_columns) > 0 or len(duplicate_columns) > 0:
        error_message = "Invalid columns:"
        indentation = " " * ERROR_INDENT_SIZE
        for duplicate_column in sorted(duplicate_columns):
            error_message += f"\n{indentation}Duplicate column: '{duplicate_column}'"
        for extra_column in sorted(extra_columns):
            error_message += f"\n{indentation}Extra column: '{extra_column}'"
        for missing_column in sorted(missing_columns):
            error_message += f"\n{indentation}Missing column: '{missing_column}'"
        raise RowValidationError(message=error_message)


def validate_csv_row(row: Dict[str, str], csv_format: CSVFormat) -> None:
    """Validates a row from a CSV file using a provided CSV format. Raises a
    `RowValidationError` if the row is invalid.
    Args:
        row: The row to validate.
        csv_format: The CSV format to validate against.
    """
    cell_errors: List[Tuple[Tuple[str, ...], CellValidationError]] = []

    # In validate_csv_column_name we allow blank column names, but if those columns
    # have values in them we should raise
    if "" in row and row[""]:
        cell_errors.append(
            (
                (),
                CellValidationError(
                    f"unexpected value '{row['']}' with no column title"
                ),
            )
        )

    # Get the cell validators for the row by applying any overrides
    cell_validators: Dict[str, CellValidator] = dict(csv_format.cell_validators)
    for row_predicate, override in csv_format.overrides:
        if row_predicate(row):
            for column in cell_validators.keys():
                cell_validators[column] = override(column, cell_validators[column])

    # Validate the columns that are present (we will raise validation errors for those
    # that aren't)
    for column in row.keys():
        if column in cell_validators.keys():
            cell_value = row[column]
            cell_validator = cell_validators[column]
            try:
                cell_validator(cell_value)
            except CellValidationError as cell_error:
                cell_errors.append(((column,), cell_error))

    row_errors: List[RowValidationError] = []
    for row_validator in csv_format.row_validators:
        try:
            row_validator(row)
        except RowValidationError as row_error:
            row_errors.append(row_error)

    if len(cell_errors) > 0 or len(row_errors) > 0:
        raise RowValidationError.from_errors(
            cell_errors=cell_errors, row_errors=row_errors
        )
