from rhp.cli import cli

cli()
