# Utilities for importing health results data files (HRDFs)

# TODO (ALLOFUS-1471): Can split this into smaller files that target HDR/PGx

from typing import Dict, TextIO, Tuple

from rhp.validation.common import (
    HDR_CELL_VALIDATORS,
    SHARED_CELL_VALIDATORS,
    SHARED_ROW_VALIDATORS,
)
from rhp.validation.constants import (
    HDRV1_HRDF_FAILURE_OPTIONAL_COLUMNS,
    HDRV1_HRDF_P_LP_REQUIRED_COLUMNS,
    Classification,
    ClinicalAnalysisType,
    ConfirmationStatus,
    CSVColumn,
    PgxGene,
)
from rhp.validation.core import (
    CellValidator,
    CSVFormat,
    OverrideFn,
    RowPredicate,
    RowValidator,
    validate_csv,
)
from rhp.validation.validators import (
    alleles_list_validator,
    base_string_validator,
    date_validator,
    gene_diplotype_and_phenotype_validator,
    make_optional,
    make_required,
    number_validator,
    options_validator,
    required_validator,
)

# Columns that are common to both HDR and PGx HRDFs
HRDF_COLUMNS: Tuple[CSVColumn, ...] = (
    CSVColumn.GENOME_CENTER_INTERNAL_ID,
    CSVColumn.BIOBANK_ID,
    CSVColumn.SAMPLE_ID,
    CSVColumn.SEX,
    CSVColumn.SEQUENCING_FILE,
    CSVColumn.VARIANT_CALL_FILE,
    CSVColumn.ASSAY_TYPE,
    CSVColumn.SEQUENCE_APPROVAL_DATE,
    CSVColumn.REPORTABLE_RANGE_VERSION,
    CSVColumn.DRAGEN_PIPELINE_VERSION,
    CSVColumn.CLINICAL_ANALYSIS_TYPE,
    CSVColumn.REVISION_NUMBER,
    CSVColumn.GENOME_CENTER,
    CSVColumn.CVL_NAME,
    CSVColumn.CVL_CLIA_DIRECTOR,
    CSVColumn.GENE_NAME,
    CSVColumn.CHROMOSOME,
    CSVColumn.POSITION,
    CSVColumn.VARIANT_REF,
    CSVColumn.VARIANT_ALT,
    CSVColumn.REFERENCE_GENOME,
)

# Columns that are specific to HDR HRDFs
HDR_HRDF_COLUMNS: Tuple[CSVColumn, ...] = HRDF_COLUMNS + (
    CSVColumn.TRANSCRIPT,
    CSVColumn.G_HGVS,
    CSVColumn.C_HGVS,
    CSVColumn.P_HGVS,
    CSVColumn.ZYGOSITY,
    CSVColumn.ALLELE_FRACTION,
    CSVColumn.PHASING,
    CSVColumn.CLASSIFICATION,
    CSVColumn.REPORTED_DISORDER,
    CSVColumn.LOW_PENETRANCE_FLAG,
    CSVColumn.CLASSIFICATION_WRITE_UP,
    CSVColumn.CLASSIFICATION_DATE,
    CSVColumn.CONFIRMATION_COMPLETE,
    CSVColumn.VARIANT_DETAILS,
)

# Cell validators that are specific to HRDFs
HRDF_CELL_VALIDATORS: Dict[CSVColumn, CellValidator] = {
    **SHARED_CELL_VALIDATORS,
    # ref and classification date are optional for variant input files because of
    # historical variants which may not have this information - we require these fields
    # in HRDFs
    CSVColumn.VARIANT_REF: base_string_validator,
    CSVColumn.CLASSIFICATION_DATE: date_validator,
    # confirmation_complete is required for P/LP variants - we make it optional here but
    # it is made required again by the P/LP override
    CSVColumn.CONFIRMATION_COMPLETE: make_optional(
        options_validator(ConfirmationStatus.values())
    ),
}

# Cell validators that are specific to HDR HRDFs
HDR_HRDF_CELL_VALIDATORS: Dict[CSVColumn, CellValidator] = {
    **HRDF_CELL_VALIDATORS,
    **HDR_CELL_VALIDATORS,
}

# Row validators that are specific to HDR HRDFs
HDR_HRDF_ROW_VALIDATORS: Tuple[RowValidator, ...] = (*SHARED_ROW_VALIDATORS,)

HDR_HRDF_OVERRIDES: Tuple[Tuple[RowPredicate, OverrideFn], ...] = (
    # P/LP override: confirmation_complete is required if the classification is P/LP
    (
        lambda row: (
            row.get(CSVColumn.CLASSIFICATION.value)
            in (Classification.PATHOGENIC, Classification.LIKELY_PATHOGENIC)
        ),
        lambda column, cell_validator: (
            make_required(cell_validator)
            if CSVColumn(column) == CSVColumn.CONFIRMATION_COMPLETE
            else cell_validator
        ),
    ),
    # P/LP override: Makes some columns required if the classification is P/LP and
    # confirmation is complete
    (
        lambda row: (
            row.get(CSVColumn.CLASSIFICATION.value)
            in (Classification.PATHOGENIC, Classification.LIKELY_PATHOGENIC)
            and row.get(CSVColumn.CONFIRMATION_COMPLETE.value)
            == ConfirmationStatus.COMPLETED.value
        ),
        lambda column, cell_validator: (
            make_required(cell_validator)
            if CSVColumn(column) in HDRV1_HRDF_P_LP_REQUIRED_COLUMNS
            else cell_validator
        ),
    ),
    # Failure override: Makes most columns optional and a few required if
    # confirmation_complete is Failed
    (
        lambda row: (
            row.get(CSVColumn.CONFIRMATION_COMPLETE.value)
            == ConfirmationStatus.FAILED.value
        ),
        lambda column, cell_validator: (
            make_optional(cell_validator)
            if CSVColumn(column) in HDRV1_HRDF_FAILURE_OPTIONAL_COLUMNS
            else cell_validator
        ),
    ),
)

# CSV format for HDR HRDFs
HDR_HRDF_FORMAT = CSVFormat(
    columns=HDR_HRDF_COLUMNS,
    cell_validators={
        column.value: validator
        for column, validator in HDR_HRDF_CELL_VALIDATORS.items()
    },
    row_validators=HDR_HRDF_ROW_VALIDATORS,
    overrides=HDR_HRDF_OVERRIDES,
)


def validate_hdr_hrdf(hdr_file: TextIO) -> None:
    """Validates a health results data file (HRDF) for HDRV1 clinical results.

    Args:
        hdr_file: The HDR file (any file-like object) to validate.
    """
    validate_csv(hdr_file, HDR_HRDF_FORMAT)


# Columns that are specific to PGx HRDFs
PGX_HRDF_COLUMNS: Tuple[CSVColumn, ...] = HRDF_COLUMNS + (
    CSVColumn.COPY_NUMBER,
    CSVColumn.DIPLOTYPE,
    CSVColumn.PHENOTYPE,
    CSVColumn.PGX_PIPELINE_VERSION,
)

# Cell validators that are specific to PGx HRDFs
PGX_HRDF_CELL_VALIDATORS: Dict[CSVColumn, CellValidator] = {
    **HRDF_CELL_VALIDATORS,
    CSVColumn.CLINICAL_ANALYSIS_TYPE: options_validator(
        (ClinicalAnalysisType.PHARMACOGENOMICS_V1,)
    ),
    # Both HDR and PGx have variant_alt but validate it differently, so we separate it
    # out here
    CSVColumn.VARIANT_ALT: alleles_list_validator,
    CSVColumn.COPY_NUMBER: make_optional(number_validator(min_value=0, integer=True)),
    CSVColumn.DIPLOTYPE: required_validator,
    CSVColumn.PHENOTYPE: required_validator,
    CSVColumn.PGX_PIPELINE_VERSION: required_validator,
    # Both HDR and PGx have gene_name but have different gene options
    CSVColumn.GENE_NAME: options_validator(PgxGene.values()),
}

# Row validators that are specific to PGx HRDFs
PGX_HRDF_ROW_VALIDATORS: Tuple[RowValidator, ...] = tuple(SHARED_ROW_VALIDATORS) + (
    gene_diplotype_and_phenotype_validator,
)

# CSV format for PGx HRDFs
PGX_HRDF_FORMAT = CSVFormat(
    columns=PGX_HRDF_COLUMNS,
    cell_validators={
        column.value: validator
        for column, validator in PGX_HRDF_CELL_VALIDATORS.items()
    },
    row_validators=PGX_HRDF_ROW_VALIDATORS,
)


def validate_pgx_hrdf(pgx_file: TextIO) -> None:
    """Validates a health results data file (HRDF) for PGxV1 clinical results.

    Args:
        pgx_file: The PGx file (any file-like object) to validate.
    """
    validate_csv(pgx_file, PGX_HRDF_FORMAT)


def validate_hrdf(file: TextIO, clinical_analysis_type: ClinicalAnalysisType) -> None:
    """Validates a health-related data file (HRDF) for a given clinical analysis type.

    Args:
        file: The file (any file-like object) to validate.
        clinical_analysis_type: TODO
    """
    if clinical_analysis_type == ClinicalAnalysisType.HEREDITARY_DISEASE_RISK_V1:
        validate_hdr_hrdf(file)
    else:  # PGxV1
        validate_pgx_hrdf(file)
