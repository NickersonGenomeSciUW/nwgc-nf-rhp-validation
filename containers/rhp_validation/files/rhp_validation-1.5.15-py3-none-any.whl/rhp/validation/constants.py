from enum import Enum
from importlib import resources
from types import MappingProxyType
from typing import Any, Dict, FrozenSet, Generator, Mapping, Tuple, cast

from ruamel.yaml import YAML

yaml = YAML(typ="safe")

CLASSIFICATION_WRITE_UP_LENGTH = 1950
LOW_PENETRANCE_FLAG_TRUE = "True"


class StrEnum(str, Enum):
    @classmethod
    def values(cls) -> Generator[str, None, None]:
        return (item.value for item in cls)


class AssayType(StrEnum):
    WGS = "WGS"


class Boolean(StrEnum):
    FALSE = "False"
    TRUE = "True"


class ConfirmationStatus(StrEnum):
    NOT_PERFORMED = "False"
    COMPLETED = "True"
    FAILED = "Failed"


class Classification(StrEnum):
    BENIGN = "Benign"
    LIKELY_BENIGN = "Likely Benign"
    VUS = "Uncertain Significance"
    LIKELY_PATHOGENIC = "Likely Pathogenic"
    PATHOGENIC = "Pathogenic"
    NOT_ASSIGNED = "Not Assigned"
    RISK_ALLELE = "Risk Allele"


class ClinicalAnalysisType(StrEnum):
    HEREDITARY_DISEASE_RISK_V1 = "HDRV1"
    PHARMACOGENOMICS_V1 = "PGxV1"


class ClinicalValidationLab(StrEnum):
    BAYLOR_COLLEGE_OF_MEDICINE = "BCM"
    COLOR = "CO"
    LABORATORY_FOR_MOLECULAR_MEDICINE = "LMM"
    UNIVERSITY_OF_WASHINGTON = "UW"


class GenomeCenter(StrEnum):
    BAYLOR_COLLEGE_OF_MEDICINE = "BCM"
    BROAD_INSTITUTE = "BI"
    UNIVERSITY_OF_WASHINGTON = "UW"


class ReferenceGenome(StrEnum):
    GRCH37 = "GRCh37"
    GRCH38 = "GRCh38"


class Sex(StrEnum):
    F = "F"
    M = "M"
    NA = "NA"


class Zygosity(StrEnum):
    HETEROZYGOUS = "Heterozygous"
    HOMOZYGOUS = "Homozygous"
    HEMIZYGOUS = "Hemizygous"
    LOW_ALLELE_FRACTION = "Low allele fraction"


# Genes used for the HDRV1 analysis type
class HdrGene(StrEnum):
    ACTA2 = "ACTA2"
    ACTC1 = "ACTC1"
    APC = "APC"
    APOB = "APOB"
    ATP7B = "ATP7B"
    BMPR1A = "BMPR1A"
    BRCA1 = "BRCA1"
    BRCA2 = "BRCA2"
    CACNA1S = "CACNA1S"
    COL3A1 = "COL3A1"
    DSC2 = "DSC2"
    DSG2 = "DSG2"
    DSP = "DSP"
    FBN1 = "FBN1"
    GLA = "GLA"
    KCNH2 = "KCNH2"
    KCNQ1 = "KCNQ1"
    LDLR = "LDLR"
    LMNA = "LMNA"
    MEN1 = "MEN1"
    MLH1 = "MLH1"
    MSH2 = "MSH2"
    MSH6 = "MSH6"
    MUTYH = "MUTYH"
    MYBPC3 = "MYBPC3"
    MYH11 = "MYH11"
    MYH7 = "MYH7"
    MYL2 = "MYL2"
    MYL3 = "MYL3"
    NF2 = "NF2"
    OTC = "OTC"
    PCSK9 = "PCSK9"
    PKP2 = "PKP2"
    PMS2 = "PMS2"
    PRKAG2 = "PRKAG2"
    PTEN = "PTEN"
    RB1 = "RB1"
    RET = "RET"
    RYR1 = "RYR1"
    RYR2 = "RYR2"
    SCN5A = "SCN5A"
    SDHAF2 = "SDHAF2"
    SDHB = "SDHB"
    SDHC = "SDHC"
    SDHD = "SDHD"
    SMAD3 = "SMAD3"
    SMAD4 = "SMAD4"
    STK11 = "STK11"
    TGFBR1 = "TGFBR1"
    TGFBR2 = "TGFBR2"
    TMEM43 = "TMEM43"
    TNNI3 = "TNNI3"
    TNNT2 = "TNNT2"
    TP53 = "TP53"
    TPM1 = "TPM1"
    TSC1 = "TSC1"
    TSC2 = "TSC2"
    VHL = "VHL"
    WT1 = "WT1"


# @rohittalwalkar
# make sure to keep rhp/frontend/src/lib/constants.ts in sync
class Disorder(StrEnum):
    """Describes a disorder recognized by the All of Us program."""

    ARRHYTHMOGENIC_CARDIOMYOPATHY = "ACM"
    ARRHYTHMOGENIC_CARDIOMYOPATHY_AND_DILATED_CARDIOMYOPATHY = "ACMDCM"
    BRUGADA_SYNDROME = "BRS"
    CATECHOLAMINERGIC_POLYMORPHIC_VENTRICULAR_TACHYCARDIA = "CPVT"
    DILATED_CARDIOMYOPATHY = "DCM"
    FABRY_DISEASE = "FD"
    FAMILIAL_ADENOMATOUS_POLYPOSIS = "FAP"
    FAMILIAL_HYPERCHOLESTEROLEMIA = "FH"
    FAMILIAL_THORACIC_AORTIC_ANEURYSM_AND_AORTIC_DISSECTION = "TAAD"
    HEREDITARY_BREAST_AND_OVARIAN_CANCER_SYNDROME = "HBOC"
    HYPERTROPHIC_CARDIOMYOPATHY = "HCM"
    JUVENILE_POLYPOSIS_SYNDROME = "JPS"
    LI_FRAUMENI_SYNDROME = "LFS"
    LOEYS_DIETZ_SYNDROME = "LDS"
    LONG_QT_SYNDROME = "LQTS"
    LYNCH_SYNDROME = "HNPCC"
    MALIGNANT_HYPERTHERMIA_SUSCEPTIBILITY = "MHS"
    MARFAN_SYNDROME = "MFS"
    MULTIPLE_ENDOCRINE_NEOPLASIA_TYPE_1 = "MEN1"
    MULTIPLE_ENDOCRINE_NEOPLASIA_TYPE_2 = "MEN2"
    MUTYH_ASSOCIATED_POLYPOSIS = "MAP"
    NEUROFIBROMATOSIS_TYPE_2 = "NF2"
    ORNITHINE_CARBAMOYLTRANSFERASE_DEFICIENCY = "OTC"
    PARAGANGLIOMAS_1 = "PGL1"
    PARAGANGLIOMAS_2 = "PGL2"
    PARAGANGLIOMAS_3 = "PGL3"
    PARAGANGLIOMAS_4 = "PGL4"
    PEUTZ_JEGHERS_SYNDROME = "PJS"
    PTEN_HAMARTOMA_TUMOR_SYNDROME = "PHTS"
    RETINOBLASTOMA = "RB"
    TUBEROUS_SCLEROSIS_COMPLEX = "TSC"
    # TODO (@devchakraborty): Check if it's fine to uppercase the v in vEDS
    VASCULAR_EHLERS_DANLOS_SYNDROME = "VEDS"
    VON_HIPPEL_LINDAU_SYNDROME = "VHL"
    WILMS_TUMOR = "WT"
    WILSON_DISEASE = "WD"


class CSVColumn(StrEnum):
    """Describes a column in a variant or HRDF CSV file."""

    # TODO (ALLOFUS-1471): Can split this enum up to target file types more granularly

    # Common to all CSV files:
    CVL_NAME = "cvl_name"  # Variant or HRDF import only
    GENE_NAME = "gene_name"
    CHROMOSOME = "chromosome"
    POSITION = "position"
    VARIANT_REF = "variant_ref"
    VARIANT_ALT = "variant_alt"
    REFERENCE_GENOME = "reference_genome"
    TRANSCRIPT = "transcript"
    C_HGVS = "chgvs"
    P_HGVS = "phgvs"
    G_HGVS = "ghgvs"
    CLASSIFICATION = "classification"
    REPORTED_DISORDER = "reported_disorder"
    LOW_PENETRANCE_FLAG = "low_penetrance_flag"
    # variant input or HRDF import only
    CLASSIFICATION_WRITE_UP = "classification_write_up"
    CLASSIFICATION_DATE = "classification_date"
    VARIANT_DETAILS = "variant_details"

    # Variant files only:
    CAID = "caid"

    # [cvl or rhp]_* fields are only for variant output:
    RHP_TRANSCRIPT = "rhp_transcript"
    BCM_TRANSCRIPT = "bcm_transcript"
    CO_TRANSCRIPT = "co_transcript"
    LMM_TRANSCRIPT = "lmm_transcript"
    UW_TRANSCRIPT = "uw_transcript"

    RHP_GHGVS = "rhp_ghgvs"
    BCM_GHGVS = "bcm_ghgvs"
    CO_GHGVS = "co_ghgvs"
    LMM_GHGVS = "lmm_ghgvs"
    UW_GHGVS = "uw_ghgvs"

    RHP_CHGVS = "rhp_chgvs"
    BCM_CHGVS = "bcm_chgvs"
    CO_CHGVS = "co_chgvs"
    LMM_CHGVS = "lmm_chgvs"
    UW_CHGVS = "uw_chgvs"

    RHP_PHGVS = "rhp_phgvs"
    BCM_PHGVS = "bcm_phgvs"
    CO_PHGVS = "co_phgvs"
    LMM_PHGVS = "lmm_phgvs"
    UW_PHGVS = "uw_phgvs"

    RHP_CLASSIFICATION = "rhp_classification"
    BCM_CLASSIFICATION = "bcm_classification"
    CO_CLASSIFICATION = "co_classification"
    LMM_CLASSIFICATION = "lmm_classification"
    UW_CLASSIFICATION = "uw_classification"

    RHP_REPORTED_DISORDER = "rhp_reported_disorder"
    BCM_REPORTED_DISORDER = "bcm_reported_disorder"
    CO_REPORTED_DISORDER = "co_reported_disorder"
    LMM_REPORTED_DISORDER = "lmm_reported_disorder"
    UW_REPORTED_DISORDER = "uw_reported_disorder"

    RHP_LOW_PENETRANCE_FLAG = "rhp_low_penetrance_flag"
    CO_LOW_PENETRANCE_FLAG = "co_low_penetrance_flag"
    UW_LOW_PENETRANCE_FLAG = "uw_low_penetrance_flag"
    BCM_LOW_PENETRANCE_FLAG = "bcm_low_penetrance_flag"
    LMM_LOW_PENETRANCE_FLAG = "lmm_low_penetrance_flag"

    BCM_CLASSIFICATION_DATE = "bcm_classification_date"
    CO_CLASSIFICATION_DATE = "co_classification_date"
    LMM_CLASSIFICATION_DATE = "lmm_classification_date"
    UW_CLASSIFICATION_DATE = "uw_classification_date"

    BCM_CLASSIFICATION_WRITE_UP = "bcm_classification_write_up"
    CO_CLASSIFICATION_WRITE_UP = "co_classification_write_up"
    LMM_CLASSIFICATION_WRITE_UP = "lmm_classification_write_up"
    UW_CLASSIFICATION_WRITE_UP = "uw_classification_write_up"

    BCM_VARIANT_DETAILS = "bcm_variant_details"
    CO_VARIANT_DETAILS = "co_variant_details"
    LMM_VARIANT_DETAILS = "lmm_variant_details"
    UW_VARIANT_DETAILS = "uw_variant_details"

    # Variant output only
    NON_HARMONIZED = "non_harmonized"
    REPORTABLE = "reportable"
    DISCORDANT = "discordant"
    VAC_QUEUE = "vac_queue"

    # HRDF import only:
    GENOME_CENTER_INTERNAL_ID = "genome_center_internal_id"
    BIOBANK_ID = "biobank_id"
    SAMPLE_ID = "sample_id"
    SEX = "sex_at_birth"
    SEQUENCING_FILE = "sequencing_file"
    VARIANT_CALL_FILE = "variant_call_file"
    ASSAY_TYPE = "assay_type"
    SEQUENCE_APPROVAL_DATE = "sequence_date"
    REPORTABLE_RANGE_VERSION = "reportable_range_version"
    DRAGEN_PIPELINE_VERSION = "pipeline_version"
    CLINICAL_ANALYSIS_TYPE = "analysis_type"
    REVISION_NUMBER = "revision_number"
    GENOME_CENTER = "genome_center"
    CVL_CLIA_DIRECTOR = "clia_director"
    CONFIRMATION_COMPLETE = "confirmation_complete"

    # HDR HRDF import only:
    ZYGOSITY = "zygosity"
    ALLELE_FRACTION = "allele_fraction"
    PHASING = "phasing"

    # PGx HRDF import only:
    COPY_NUMBER = "copy_number"
    DIPLOTYPE = "diplotype"
    PHENOTYPE = "phenotype"
    PGX_PIPELINE_VERSION = "pgx_pipeline_version"


# Classifications that are reportable
REPORTABLE_CLASSIFICATIONS: FrozenSet[Classification] = frozenset(
    (Classification.PATHOGENIC, Classification.LIKELY_PATHOGENIC)
)

# Fields that are required for confirmed P/LP HDRV1 HRDFs but optional otherwise
HDRV1_HRDF_P_LP_REQUIRED_COLUMNS = (
    CSVColumn.REPORTED_DISORDER,
    CSVColumn.CLASSIFICATION_WRITE_UP,
)

# Fields that are not required for failure HDRV1 HRDFs (i.e., when confirmation_complete
# is set to "Failed")
HDRV1_HRDF_FAILURE_OPTIONAL_COLUMNS = (
    CSVColumn.REFERENCE_GENOME,
    CSVColumn.GENE_NAME,
    CSVColumn.CHROMOSOME,
    CSVColumn.POSITION,
    CSVColumn.VARIANT_REF,
    CSVColumn.VARIANT_ALT,
    CSVColumn.TRANSCRIPT,
    CSVColumn.G_HGVS,
    CSVColumn.C_HGVS,
    CSVColumn.ZYGOSITY,
    CSVColumn.ALLELE_FRACTION,
    CSVColumn.PHASING,
    CSVColumn.CLASSIFICATION,
    CSVColumn.CLASSIFICATION_WRITE_UP,
    CSVColumn.CLASSIFICATION_DATE,
    CSVColumn.CONFIRMATION_COMPLETE,
    CSVColumn.VARIANT_DETAILS,
)


def read_reference_file(
    clinical_analysis_type: ClinicalAnalysisType, file_name: str
) -> Dict[str, Any]:
    """Helper function to read a AoU reference file. The file is expected to be in the YAML
    file format; the dictionary representation is returned.

    Args:
        clinical_analysis_type:
            The clinical analysis type the reference file is used for. This determines
            the folder in which the file will be found.
        file_name: The name of the AoU reference file to read.
    """
    with resources.open_text(
        f"rhp.validation.reference_files.{clinical_analysis_type.value}", file_name
    ) as resource_file:
        return cast(Dict[str, Any], yaml.load(resource_file))


def get_transcripts_from_reference_files() -> Mapping[HdrGene, Tuple[str, ...]]:
    """Helper function to read transcripts from the AoU reference files."""
    transcripts_data = read_reference_file(
        ClinicalAnalysisType.HEREDITARY_DISEASE_RISK_V1, "transcripts.yaml"
    )
    return {
        HdrGene(gene): (
            # Remove version number from transcripts (versions not considered in
            # validation)
            tuple(transcript.split(".")[0] for transcript in transcripts)
        )
        for gene, transcripts in transcripts_data["transcripts_by_gene"].items()
    }


VALID_TRANSCRIPTS_BY_HDR_GENE: Mapping[HdrGene, Tuple[str, ...]] = MappingProxyType(
    get_transcripts_from_reference_files()
)


def get_disorders_from_reference_files() -> Mapping[HdrGene, Tuple[Disorder, ...]]:
    disorders_data = read_reference_file(
        ClinicalAnalysisType.HEREDITARY_DISEASE_RISK_V1, "disorders.yaml"
    )
    disorders_by_gene: Dict[HdrGene, Tuple[Disorder, ...]] = {}
    for disorder_acronym, disorder_data in disorders_data["disorders"].items():
        disorder = Disorder(disorder_acronym)
        for gene_name in disorder_data["genes"]:
            gene = HdrGene(gene_name)
            disorders_by_gene[gene] = disorders_by_gene.get(gene, ()) + (disorder,)
    return disorders_by_gene


VALID_DISORDERS_BY_HDR_GENE: Mapping[HdrGene, Tuple[Disorder, ...]] = MappingProxyType(
    get_disorders_from_reference_files()
)

# NC_ GenBank references by chromosome for GRCh37
REFERENCES_BY_CHROMOSOME: Dict[str, str] = {
    "1": "NC_000001.10",
    "2": "NC_000002.11",
    "3": "NC_000003.11",
    "4": "NC_000004.11",
    "5": "NC_000005.9",
    "6": "NC_000006.11",
    "7": "NC_000007.13",
    "8": "NC_000008.10",
    "9": "NC_000009.11",
    "10": "NC_000010.10",
    "11": "NC_000011.9",
    "12": "NC_000012.11",
    "13": "NC_000013.10",
    "14": "NC_000014.8",
    "15": "NC_000015.9",
    "16": "NC_000016.9",
    "17": "NC_000017.10",
    "18": "NC_000018.9",
    "19": "NC_000019.9",
    "20": "NC_000020.10",
    "21": "NC_000021.8",
    "22": "NC_000022.10",
    "X": "NC_000023.10",
    "Y": "NC_000024.9",
}


class HgvsNomenclatureType(StrEnum):
    C_HGVS = "c"
    G_HGVS = "g"
    P_HGVS = "p"


# Genes used for the PGxV1 analysis type
class PgxGene(StrEnum):
    TPMT = "TPMT"
    NUDT15 = "NUDT15"
    DPYD = "DPYD"
    UGT1A1 = "UGT1A1"
    SLCO1B1 = "SLCO1B1"
    CYP2C19 = "CYP2C19"
    G6PD = "G6PD"


class PgxPhenotype(StrEnum):
    DECREASED_FUNCTION = "decreased function"
    INTERMEDIATE_METABOLIZER = "intermediate metabolizer"
    LIKELY_INTERMEDIATE_METABOLIZER = "likely intermediate metabolizer"
    LIKELY_POOR_METABOLIZER = "likely poor metabolizer"
    NORMAL_FUNCTION = "normal function"
    NORMAL_METABOLIZER = "normal metabolizer"
    POOR_FUNCTION = "poor function"
    POOR_METABOLIZER = "poor metabolizer"
    RAPID_METABOLIZER = "rapid metabolizer"
    ULTRARAPID_METABOLIZER = "ultrarapid metabolizer"
    DEFICIENT = "deficient"
    VARIABLE = "variable"
    NORMAL = "normal"
    INDETERMINATE = "indeterminate"


def get_translations_from_reference_files() -> Dict[PgxGene, Dict[str, PgxPhenotype]]:
    """Helper function to read PGx diplotype/phenotype translations from the AoU reference
    files.
    """
    diplotypes_data = read_reference_file(
        ClinicalAnalysisType.PHARMACOGENOMICS_V1, "translations.yaml"
    )
    return {
        PgxGene(gene): {
            diplotype: PgxPhenotype(phenotype)
            for diplotype, phenotype in diplotypes_and_phenotypes.items()
        }
        for gene, diplotypes_and_phenotypes in diplotypes_data["translations"].items()
    }


VALID_DIPLOTYPES_AND_PHENOTYPES_BY_PGX_GENE: Mapping[
    PgxGene, Mapping[str, PgxPhenotype]
] = MappingProxyType(
    {
        gene: MappingProxyType(diplotypes_dict)
        for gene, diplotypes_dict in get_translations_from_reference_files().items()
    }
)
