from rhp.validation.constants import ClinicalAnalysisType

VALID_HRDF_DATA = (
    "filename,clinical_analysis_type",
    (
        ("hdr/valid.csv", ClinicalAnalysisType.HEREDITARY_DISEASE_RISK_V1),
        ("hdr/failed.csv", ClinicalAnalysisType.HEREDITARY_DISEASE_RISK_V1),
        ("pgx/valid.csv", ClinicalAnalysisType.PHARMACOGENOMICS_V1),
    ),
)

INVALID_HDR_HRDF_DATA = (
    "filename,expected_summary_verbose,expected_summary_concise",
    (
        (
            "hdr/extra_column.csv",
            (
                "CSV validation failed:\n"
                "  [Row 0] Invalid columns:\n"
                "    Extra column: 'extra_column'"
            ),
            (
                "CSV validation failed:\n"
                "  [1 row] Invalid columns:\n"
                "    Extra column: 'extra_column'"
            ),
        ),
        (
            "hdr/missing_column.csv",
            (
                "CSV validation failed:\n"
                "  [Row 0] Invalid columns:\n"
                "    Missing column: 'reference_genome'"
            ),
            (
                "CSV validation failed:\n"
                "  [1 row] Invalid columns:\n"
                "    Missing column: 'reference_genome'"
            ),
        ),
        (
            "hdr/missing_required.csv",
            ("CSV validation failed:\n  [Row 1][clia_director] cannot be empty"),
            ("CSV validation failed:\n  [clia_director][1 cell] cannot be empty"),
        ),
        (
            "hdr/missing_gene.csv",
            (
                "CSV validation failed:\n"
                "  [Row 1][gene_name] invalid value '', options are: ACTA2, ACTC1, "
                "APC, APOB, ATP7B, BMPR1A, BRCA1, BRCA2, CACNA1S, COL3A1, DSC2, DSG2, "
                "DSP, FBN1, GLA, KCNH2, KCNQ1, LDLR, LMNA, MEN1, MLH1, MSH2, MSH6, "
                "MUTYH, MYBPC3, MYH11, MYH7, MYL2, MYL3, NF2, OTC, PCSK9, PKP2, PMS2, "
                "PRKAG2, PTEN, RB1, RET, RYR1, RYR2, SCN5A, SDHAF2, SDHB, SDHC, SDHD, "
                "SMAD3, SMAD4, STK11, TGFBR1, TGFBR2, TMEM43, TNNI3, TNNT2, TP53, "
                "TPM1, TSC1, TSC2, VHL, WT1"
            ),
            (
                "CSV validation failed:\n"
                "  [gene_name][1 cell] invalid value '', options are: ACTA2, ACTC1, "
                "APC, APOB, ATP7B, BMPR1A, BRCA1, BRCA2, CACNA1S, COL3A1, DSC2, DSG2, "
                "DSP, FBN1, GLA, KCNH2, KCNQ1, LDLR, LMNA, MEN1, MLH1, MSH2, MSH6, "
                "MUTYH, MYBPC3, MYH11, MYH7, MYL2, MYL3, NF2, OTC, PCSK9, PKP2, PMS2, "
                "PRKAG2, PTEN, RB1, RET, RYR1, RYR2, SCN5A, SDHAF2, SDHB, SDHC, SDHD, "
                "SMAD3, SMAD4, STK11, TGFBR1, TGFBR2, TMEM43, TNNI3, TNNT2, TP53, "
                "TPM1, TSC1, TSC2, VHL, WT1"
            ),
        ),
        (
            "hdr/various_errors.csv",
            (
                "CSV validation failed:\n"
                "  [Row 0] Invalid columns:\n"
                "    Extra column: 'extra_column'\n"
                "    Missing column: 'position'\n"
                "  [Row 1][classification_date] invalid value '2021-13-04', expected "
                "date format YYYY-MM-DD\n"
                "  [Row 1][variant_details] invalid value 'blah', expected a URL\n"
                "  [Row 2][classification_date] invalid value 'blah', expected date "
                "format YYYY-MM-DD\n"
                "  [Row 2][variant_alt] invalid base string 'X', expected a string "
                "comprised of A, C, T, and G only\n"
                "  [Row 3][gene_name, reported_disorder] invalid disorder 'HCM' for "
                "gene MUTYH, accepted disorders are: MAP\n"
                "  [Row 3][gene_name, transcript] invalid transcript '' for gene "
                "MUTYH, accepted transcripts are: NM_001128425\n"
                "  [Row 3][transcript] invalid RefSeq transcript ID '', expected an "
                "ID that looks like NM_123456.7\n"
                "  [Row 4][allele_fraction] invalid value '1.5', expected a number "
                "between 0 and 1\n"
                "  [Row 5][biobank_id] invalid Biobank ID '111111111', expected the "
                "letter A or T followed by a 9-digit number\n"
                "  [Row 5][sample_id] invalid sample ID '1111111111', expected an "
                "11-digit number\n"
                "  [Row 5][variant_details] invalid value 'blah', expected a URL\n"
                "  [Row 6][phasing] cannot be empty\n"
                "  [Row 6][reported_disorder] cannot be empty"
            ),
            (
                "CSV validation failed:\n"
                "  [1 row] Invalid columns:\n"
                "    Extra column: 'extra_column'\n"
                "    Missing column: 'position'\n"
                "  [allele_fraction][1 cell] invalid value '1.5', expected a number "
                "between 0 and 1\n"
                "  [biobank_id][1 cell] invalid Biobank ID '111111111', expected the "
                "letter A or T followed by a 9-digit number\n"
                "  [classification_date][1 cell] invalid value '2021-13-04', expected "
                "date format YYYY-MM-DD\n"
                "  [classification_date][1 cell] invalid value 'blah', expected date "
                "format YYYY-MM-DD\n"
                "  [gene_name, reported_disorder][1 row] invalid disorder 'HCM' for "
                "gene MUTYH, accepted disorders are: MAP\n"
                "  [gene_name, transcript][1 row] invalid transcript '' for gene "
                "MUTYH, accepted transcripts are: NM_001128425\n"
                "  [phasing][1 cell] cannot be empty\n"
                "  [reported_disorder][1 cell] cannot be empty\n"
                "  [sample_id][1 cell] invalid sample ID '1111111111', expected an "
                "11-digit number\n"
                "  [transcript][1 cell] invalid RefSeq transcript ID '', expected an "
                "ID that looks like NM_123456.7\n"
                "  [variant_alt][1 cell] invalid base string 'X', expected a string "
                "comprised of A, C, T, and G only\n"
                "  [variant_details][2 cells] invalid value 'blah', expected a URL"
            ),
        ),
        (
            "hdr/length_exceeded.csv",
            (
                "CSV validation failed:\n"
                "  [Row 1][classification, classification_write_up] invalid "
                "classification write-up length 1951 - variants with classification "
                "'Pathogenic' must have a classification write-up with length no "
                "greater than 1950"
            ),
            (
                "CSV validation failed:\n"
                "  [classification, classification_write_up][1 row] invalid "
                "classification write-up length 1951 - variants with classification "
                "'Pathogenic' must have a classification write-up with length no "
                "greater than 1950"
            ),
        ),
        (
            "hdr/missing_column_failed.csv",
            (
                "CSV validation failed:\n"
                "  [Row 1][biobank_id] invalid Biobank ID '', expected the letter A or "
                "T followed by a 9-digit number\n"
                "  [Row 1][sample_id] invalid sample ID '', expected an 11-digit number"
            ),
            (
                "CSV validation failed:\n"
                "  [biobank_id][1 cell] invalid Biobank ID '', expected the letter A "
                "or T followed by a 9-digit number\n"
                "  [sample_id][1 cell] invalid sample ID '', expected an 11-digit "
                "number"
            ),
        ),
        (
            "hdr/p_lp_errors.csv",
            (
                "CSV validation failed:\n"
                "  [Row 1][confirmation_complete] cannot be empty\n"
                "  [Row 2][classification_write_up] cannot be empty\n"
                "  [Row 2][reported_disorder] cannot be empty"
            ),
            (
                "CSV validation failed:\n"
                "  [classification_write_up][1 cell] cannot be empty\n"
                "  [confirmation_complete][1 cell] cannot be empty\n"
                "  [reported_disorder][1 cell] cannot be empty"
            ),
        ),
    ),
)

INVALID_PGX_HRDF_DATA = (
    "filename,expected_summary_verbose,expected_summary_concise",
    (
        (
            "pgx/various_errors.csv",
            (
                "CSV validation failed:\n"
                "  [Row 1][diplotype, gene_name, phenotype] invalid phenotype "
                "'normal function' for gene CYP2C19 and diplotype *1/*2, accepted "
                "phenotype is intermediate metabolizer\n"
                "  [Row 1][variant_alt] invalid allele list \"['G', 'GX']\", expected "
                "a Python-style list of strings comprised of A, C, T, and G only "
                "(e.g., ['C', 'TG'])\n"
                "  [Row 2][diplotype, gene_name] invalid diplotype 'B/C' for gene "
                "SLCO1B1, accepted diplotypes are: *1/*1, *1/*15, *1/*17, *1/*5, "
                "*15/*15, *15/*17, *17/*17, *5/*15, *5/*17, *5/*5, NA\n"
                "  [Row 3][diplotype] cannot be empty\n"
                "  [Row 3][phenotype] cannot be empty\n"
                "  [Row 4][diplotype, gene_name, phenotype] invalid phenotype 'normal "
                "function' for gene G6PD and diplotype B/B, accepted phenotype is "
                "normal"
            ),
            (
                "CSV validation failed:\n"
                "  [diplotype][1 cell] cannot be empty\n"
                "  [diplotype, gene_name][1 row] invalid diplotype 'B/C' for gene "
                "SLCO1B1, accepted diplotypes are: *1/*1, *1/*15, *1/*17, *1/*5, "
                "*15/*15, *15/*17, *17/*17, *5/*15, *5/*17, *5/*5, NA\n"
                "  [diplotype, gene_name, phenotype][1 row] invalid phenotype 'normal "
                "function' for gene CYP2C19 and diplotype *1/*2, accepted phenotype is "
                "intermediate metabolizer\n"
                "  [diplotype, gene_name, phenotype][1 row] invalid phenotype 'normal "
                "function' for gene G6PD and diplotype B/B, accepted phenotype is "
                "normal\n"
                "  [phenotype][1 cell] cannot be empty\n"
                "  [variant_alt][1 cell] invalid allele list \"['G', 'GX']\", expected "
                "a Python-style list of strings comprised of A, C, T, and G only "
                "(e.g., ['C', 'TG'])"
            ),
        ),
    ),
)

VARIANT_INPUT_DATA = (
    "filename,expected_output,expected_exit_code",
    (
        (
            "valid.csv",
            "CSV validation succeeded!",
            0,
        ),
        (
            "various_errors.csv",
            "CSV validation failed:\n"
            "  [Row 2][classification_date] invalid value 'blah', expected date format "
            "YYYY-MM-DD\n"
            "  [Row 2][position] invalid value '', expected an integer greater than or "
            "equal to 1\n"
            "  [Row 2][transcript, ghgvs] gHGVS validation error: NC_000001.10:g.1C>X: "
            "char 18: Syntax error\n"
            "  [Row 2][variant_alt] invalid base string 'X', expected a string "
            "comprised of A, C, T, and G only\n"
            "  [Row 2][variant_details] invalid value 'blah', expected a URL\n"
            "  [Row 3][gene_name, reported_disorder] invalid disorder 'HCM' for gene "
            "MUTYH, accepted disorders are: MAP\n"
            "  [Row 3][gene_name, transcript] invalid transcript '' for gene MUTYH, "
            "accepted transcripts are: NM_001128425\n"
            "  [Row 3][position] invalid value '', expected an integer greater than or "
            "equal to 1\n"
            "  [Row 3][transcript] invalid RefSeq transcript ID '', expected an ID "
            "that looks like NM_123456.7\n"
            "  [Row 5][ghgvs] invalid gHGVS nomenclature '', expected a value that "
            "looks like 'chr17.GRCh37:g.41245513T>A'\n"
            "  [Row 5][position] invalid value '', expected an integer greater than "
            "or equal to 1\n"
            "  [Row 6][position] invalid value '', expected an integer greater than "
            "or equal to 1",
            1,
        ),
    ),
)
