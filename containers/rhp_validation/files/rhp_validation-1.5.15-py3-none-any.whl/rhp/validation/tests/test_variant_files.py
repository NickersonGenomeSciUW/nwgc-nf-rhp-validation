from pathlib import Path
from shutil import copyfileobj

import pytest
from click.testing import CliRunner

from rhp.cli import cli
from rhp.validation.core import CSVValidationError
from rhp.validation.tests.cases import VARIANT_INPUT_DATA
from rhp.validation.tests.util import get_test_file
from rhp.validation.variant_files import validate_variant_input_file

TEST_FILES_PACKAGE = "rhp.validation.tests.test_files.variant_files"
CSV_TEST_FILENAME = "test.csv"


@pytest.mark.parametrize(*VARIANT_INPUT_DATA)
def test_validate_variant_input_file(
    filename: str, expected_output: str, expected_exit_code: int
) -> None:
    """Tests that `validate_variant_input_file` raises the correct exception for an invalid
    variant input file (or doesn't raise for a valid file).
    """
    variant_input_file = get_test_file(TEST_FILES_PACKAGE, filename)
    if expected_exit_code == 0:
        validate_variant_input_file(variant_input_file)
    else:
        with pytest.raises(CSVValidationError) as error:
            validate_variant_input_file(variant_input_file)
        assert str(error.value) == expected_output


@pytest.mark.parametrize(*VARIANT_INPUT_DATA)
def test_validate_variant_input_file_cli(
    filename: str, expected_output: str, expected_exit_code: int
) -> None:
    """Tests that a variant file can be processed by the CLI and print the correct error
    message (or print a success message for a valid file).
    """
    runner = CliRunner()
    with runner.isolated_filesystem() as tmp_path:
        tmp_csv_path = Path(tmp_path) / CSV_TEST_FILENAME
        with open(tmp_csv_path, "w") as csv_file:
            copyfileobj(get_test_file(TEST_FILES_PACKAGE, filename), csv_file)

        result = runner.invoke(
            cli,
            [
                "validate",
                "variant-input-file",
                "--verbose",
                "--input-file",
                str(tmp_csv_path),
            ],
        )
        assert result.exit_code == expected_exit_code
        assert result.output == f"{expected_output}\n"


@pytest.mark.parametrize(
    ("input_file_path", "expected_valid_file_path", "expected_invalid_file_path"),
    (
        (
            "various_errors.csv",
            "various_errors_valid.csv",
            "various_errors_invalid.csv",
        ),
        ("valid.csv", "valid.csv", "empty.csv"),
    ),
)
def test_variant_input_file_split_cli(
    input_file_path: str,
    expected_valid_file_path: str,
    expected_invalid_file_path: str,
) -> None:
    """Tests that a variant input file can be split into valid and invalid parts via the
    CLI.
    """
    runner = CliRunner()
    with runner.isolated_filesystem() as tmp:
        tmp_path = Path(tmp)
        test_input_file_path = tmp_path / "input.csv"
        test_valid_file_path = tmp_path / "valid.csv"
        test_invalid_file_path = tmp_path / "invalid.csv"

        # Copy the test input file from package to disk
        with open(test_input_file_path, "w") as input_file:
            copyfileobj(get_test_file(TEST_FILES_PACKAGE, input_file_path), input_file)

        # Run the split CLI
        args = (
            "split",
            "variant-input-file",
            "--input-file",
            str(test_input_file_path),
            "--valid-output-file",
            str(test_valid_file_path),
            "--invalid-output-file",
            str(test_invalid_file_path),
        )

        result = runner.invoke(cli, args)
        assert result.exit_code == 0

        # Check the valid output
        with open(test_valid_file_path) as valid_file:
            assert (
                valid_file.read()
                == get_test_file(TEST_FILES_PACKAGE, expected_valid_file_path).read()
            )

        # Check the invalid output
        with open(test_invalid_file_path) as invalid_file:
            assert (
                invalid_file.read()
                == get_test_file(TEST_FILES_PACKAGE, expected_invalid_file_path).read()
            )
