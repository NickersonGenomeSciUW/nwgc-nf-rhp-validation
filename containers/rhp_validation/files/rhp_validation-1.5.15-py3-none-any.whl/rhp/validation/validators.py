import ast
import re
from datetime import datetime
from functools import lru_cache
from typing import TYPE_CHECKING, Callable, Dict, Iterable, Optional
from urllib.parse import urlparse

from rhp.vendor.hgvs.exceptions import HGVSParseError

from rhp.validation.constants import (
    CLASSIFICATION_WRITE_UP_LENGTH,
    REFERENCES_BY_CHROMOSOME,
    REPORTABLE_CLASSIFICATIONS,
    VALID_DIPLOTYPES_AND_PHENOTYPES_BY_PGX_GENE,
    VALID_DISORDERS_BY_HDR_GENE,
    VALID_TRANSCRIPTS_BY_HDR_GENE,
    Classification,
    CSVColumn,
    Disorder,
    HdrGene,
    HgvsNomenclatureType,
    PgxGene,
)
from rhp.validation.core import CellValidationError, CellValidator, RowValidationError

if TYPE_CHECKING:
    from rhp.vendor.hgvs.parser import Parser as HgvsParserType


@lru_cache(maxsize=None)
def get_hgvs_parser() -> 'HgvsParserType':
    # hgvs takes about 1 second to load - import lazily to speed up startup time
    # pylint: disable=import-outside-toplevel
    from rhp.vendor.hgvs.parser import Parser as HgvsParser

    return HgvsParser()


def make_optional(validator: CellValidator) -> CellValidator:
    """Given a cell validator, returns a wrapped validator that allows blank values.

    Args:
        validator: The cell validator to wrap to allow blank values.
    """

    def optional_validator(value: str) -> None:
        if not value:
            return
        validator(value)

    return optional_validator


def make_required(validator: CellValidator) -> CellValidator:
    """Given a cell validator, makes it required by running `required_validator` on the
    value first.
    """

    def wrapped_validator(value: str) -> None:
        required_validator(value)
        validator(value)

    return wrapped_validator


def required_validator(value: str) -> None:
    """A cell validator that raises `CellValidationError` if the value is empty.

    Args:
        value: The value to validate.
    """
    if not value:
        raise CellValidationError("cannot be empty")


def options_validator(valid_values: Iterable[str]) -> CellValidator:
    """Returns a cell validator that raises `CellValidationError` if the value is not
    amongst a fixed set of options.

    Args:
        valid_values: The set of valid values to use to construct the cell validator.
    """
    values = set(valid_values)
    options_string = ", ".join(sorted(values))

    def validator(value: str) -> None:
        if value not in values:
            raise CellValidationError(
                f"invalid value '{value}', options are: {options_string}"
            )

    return validator


def date_validator(value: str) -> None:
    """A cell validator that raises `CellValidationError` if the value is not a valid date
    in YYYY-MM-DD format.

    Args:
        value: The value to validate.
    """
    try:
        datetime.strptime(value, "%Y-%m-%d")
    except ValueError as e:
        raise CellValidationError(
            f"invalid value '{value}', expected date format YYYY-MM-DD"
        ) from e


def number_validator(
    min_value: Optional[float] = None,
    max_value: Optional[float] = None,
    integer: bool = False,
) -> CellValidator:
    """Returns a cell validator that raises `CellValidationError` if the value is not a
    valid number, optionally with range or integral constraints.

    Args:
        min_value:
            If specified and not `None`, values less than this argument will cause the
            cell validator to raise.
        max_value:
            If specified and not `None`, values greater than this argument will cause
            the cell validator to raise.
        integer:
            If `True`, values that are not integral will cause the cell validator to
            raise.
    """
    a_number = "an integer" if integer else "a number"
    error_message = (
        f"expected {a_number} between {min_value} and {max_value}"
        if min_value is not None and max_value is not None
        else f"expected {a_number} greater than or equal to {min_value}"
        if min_value is not None
        else f"expected {a_number} less than or equal to {max_value}"
        if max_value is not None
        else f"expected {a_number}"
    )

    def validator(value: str) -> None:
        try:
            num = float(value)
        except ValueError as e:
            raise CellValidationError(
                f"invalid value '{value}', {error_message}"
            ) from e

        if (
            (integer and not num.is_integer())
            or (min_value is not None and num < min_value)
            or (max_value is not None and num > max_value)
        ):
            raise CellValidationError(f"invalid value '{value}', {error_message}")

    return validator


def url_validator(value: str) -> None:
    """A cell validator that raises `CellValidationError` if the value is not a well-formed
    URL.

    Args:
        value: The value to validate.
    """
    try:
        parse_result = urlparse(value)
        if not all([parse_result.scheme, parse_result.netloc]):
            raise CellValidationError(f"invalid value '{value}', expected a URL")
    except ValueError as e:
        raise CellValidationError(f"invalid value '{value}', expected a URL") from e


def length_validator(length: int) -> CellValidator:
    """Returns a cell validator that raises `CellValidationError` if the value has length
    above the provided length.

    Args:
        length: The maximum length for the validated value.
    """

    def validator(value: str) -> None:
        if len(value) > length:
            raise CellValidationError(f"invalid value, maximum length is {length}")

    return validator


def regex_validator(
    regex_expression: str, error_message_fn: Optional[Callable[[str], str]] = None
) -> CellValidator:
    """Returns a cell validator that raises `CellValidationError` if the value does not
    match the provided regex.

    Args:
        regex_expression: The regex to match the validated value against.
        error_message_fn:
            An optional function that generates the error message given an invalid input
            value.
    """
    regex = re.compile(regex_expression)

    def validator(value: str) -> None:
        if not regex.match(value):
            raise CellValidationError(
                error_message_fn(value)
                if error_message_fn
                else f"invalid value '{value}'"
            )

    return validator


def is_transcript_valid_for_gene(gene: HdrGene, transcript: str) -> bool:
    """Returns true if the given transcript is valid for the given gene. The transcript is
    looked up against a list of valid transcripts and is considered valid if a match is
    found (ignoring minor versions).

    Args:
        gene: The gene to check the transcript for.
        transcript: The transcript to check the validity for.
    """
    try:
        refseq_transcript_id_validator(transcript)
    except CellValidationError:
        return False

    transcript_without_version = transcript.split(".")[0]
    return transcript_without_version in VALID_TRANSCRIPTS_BY_HDR_GENE[gene]


def gene_and_transcript_validator(values: Dict[str, str]) -> None:
    """A row validator that checks if the transcript in the row is accepted by All of Us
    for the gene in the row. The transcript is looked up against a list of valid
    transcripts for the gene and is considered valid if a match is found (ignoring minor
    versions of the transcript).
    """
    if CSVColumn.GENE_NAME not in values or CSVColumn.TRANSCRIPT not in values:
        # Let column validation catch missing columns
        return
    gene_name = values[CSVColumn.GENE_NAME]
    transcript = values[CSVColumn.TRANSCRIPT]
    if gene_name not in HdrGene.values():
        # Let gene validation catch invalid genes
        return
    gene = HdrGene(gene_name)
    if not is_transcript_valid_for_gene(gene, transcript):
        valid_transcripts_string = ", ".join(VALID_TRANSCRIPTS_BY_HDR_GENE[gene])
        raise RowValidationError.from_errors(
            cell_errors=(
                (
                    (CSVColumn.GENE_NAME, CSVColumn.TRANSCRIPT),
                    CellValidationError(
                        f"invalid transcript '{transcript}' for gene {gene_name}, accepted "
                        f"transcripts are: {valid_transcripts_string}"
                    ),
                ),
            )
        )


clingen_variant_id_validator = regex_validator(
    r"^CA\d+$",
    lambda value: (
        f"invalid ClinGen variant identifier '{value}', expected CA followed by a "
        "number, e.g., CA12345"
    ),
)
clingen_variant_id_validator.__doc__ = """
    A cell validator that raises `CellValidationError` if the value is not a valid
    ClinGen variant identifier in the form CA12345 (CA followed by some number of any
    length).

    Args:
        value: The value to validate.
"""

refseq_transcript_id_validator = regex_validator(
    r"^NM_\d+(\.\d+)?$",
    lambda value: (
        f"invalid RefSeq transcript ID '{value}', expected an ID that looks like "
        "NM_123456.7"
    ),
)
refseq_transcript_id_validator.__doc__ = """
    A cell validator that raises `CellValidationError` if the value is not a valid
    RefSeq transcript ID that looks like NM_123456.7 (NM_ followed by some digits with
    an optional period amongst the digits).
"""

BASE_STRING_REGEX = r"^[ACTG]+$"
base_string_validator = regex_validator(
    BASE_STRING_REGEX,
    lambda value: (
        f"invalid base string '{value}', expected a string comprised of A, C, T, and G "
        "only"
    ),
)
base_string_validator.__doc__ = """
    A cell validator that raises `CellValidationError` if the value is not a valid base
    string, a string comprised of A, C, T, and G only.
"""

BIOBANK_ID_REGEX = r"[AT]\d{9}"
biobank_id_validator = regex_validator(
    f"^{BIOBANK_ID_REGEX}$",
    lambda value: (
        f"invalid Biobank ID '{value}', expected the letter A or T followed by a "
        "9-digit number"
    ),
)
biobank_id_validator.__doc__ = """
    A cell validator that raises `CellValidationError` if the value is not a valid
    Biobank ID, the letter A (or T for testing) followed by a 9-digit number.
"""

SAMPLE_ID_REGEX = r"\d{11}"
sample_id_validator = regex_validator(
    f"^{SAMPLE_ID_REGEX}$",
    lambda value: f"invalid sample ID '{value}', expected an 11-digit number",
)
sample_id_validator.__doc__ = """
    A cell validator that raises `CellValidationError` if the value is not a valid
    sample ID, an 11-digit number.
"""


def ref_and_alt_validator(values: Dict[str, str]) -> None:
    if not values.get(CSVColumn.VARIANT_REF) or not values.get(CSVColumn.VARIANT_ALT):
        # Let column validation catch missing columns
        return
    ref = values[CSVColumn.VARIANT_REF]
    alt = values[CSVColumn.VARIANT_ALT]
    if ref == alt:
        raise RowValidationError.from_errors(
            cell_errors=(
                (
                    (CSVColumn.VARIANT_REF, CSVColumn.VARIANT_ALT),
                    CellValidationError(
                        f"expected ref and alt to differ, they are both '{ref}'"
                    ),
                ),
            )
        )


def gene_and_disorder_validator(values: Dict[str, str]) -> None:
    if not values.get(CSVColumn.GENE_NAME) or not values.get(
        CSVColumn.REPORTED_DISORDER
    ):
        # Let column validation catch missing columns
        return
    gene_name = values[CSVColumn.GENE_NAME]
    disorder_abbrev = values[CSVColumn.REPORTED_DISORDER]
    if gene_name not in HdrGene.values():
        # Let gene validation catch invalid genes
        return
    if disorder_abbrev not in Disorder.values():
        # Let disorder validation catch invalid disorders
        return
    gene = HdrGene(gene_name)
    disorder = Disorder(disorder_abbrev)
    if disorder not in VALID_DISORDERS_BY_HDR_GENE[gene]:
        valid_disorders_string = ", ".join(
            disorder.value for disorder in VALID_DISORDERS_BY_HDR_GENE[gene]
        )
        raise RowValidationError.from_errors(
            cell_errors=(
                (
                    (CSVColumn.GENE_NAME, CSVColumn.REPORTED_DISORDER),
                    CellValidationError(
                        f"invalid disorder '{disorder_abbrev}' for gene {gene_name}, "
                        f"accepted disorders are: {valid_disorders_string}"
                    ),
                ),
            )
        )


chgvs_validator = regex_validator(
    r"^c\.",
    lambda value: (
        f"invalid cHGVS nomenclature '{value}', expected a value beginning with 'c.'"
    ),
)

phgvs_validator = regex_validator(
    r"^p\.",
    lambda value: (
        f"invalid pHGVS nomenclature '{value}', expected a value beginning with 'p.'"
    ),
)

CHROMOSOME_REGEX = "(?P<chromosome>[1-9]|1[0-9]|2[0-2]|[Xx]|[Yy])"
GHGVS_REGEX = f"^chr{CHROMOSOME_REGEX}\\.GRCh37:g\\."
GHGVS_REGEX_OBJECT = re.compile(GHGVS_REGEX)

ghgvs_validator = regex_validator(
    GHGVS_REGEX,
    lambda value: (
        f"invalid gHGVS nomenclature '{value}', expected a value that looks like "
        "'chr17.GRCh37:g.41245513T>A'"
    ),
)


def validate_hgvs(
    nomenclature_type: HgvsNomenclatureType,
    reference: str,
    value: str,
) -> None:
    """Helper function for `hgvs_validator` that validates a nomenclature given a
    reference.

    Args:
        nomenclature_type: The type of HGVS nomenclature ('c', 'g', or 'p')
        reference: TODO
        value: The HGVS value to validate
    """
    try:
        # Protein deletion-insertions with a terminal stop codon indicated with an asterisk
        # are not natively parsable by the RHP-vendored hgvs library, so we have to
        # convert asterisk to "Ter" under the hood.
        if nomenclature_type == HgvsNomenclatureType.P_HGVS:
            value = re.sub(r'\*$', 'Ter', value)
        result = get_hgvs_parser().parse(f"{reference}:{value}")
        if result.type != nomenclature_type.value:
            raise CellValidationError(
                f"expected '{value}' to be in {nomenclature_type.value}HGVS "
                f"nomenclature, got {result.type}HGVS"
            )
    except HGVSParseError as error:
        raise CellValidationError(
            f"{nomenclature_type.value}HGVS validation error: {error}"
        ) from error


HGVS_CELL_VALIDATOR_BY_COLUMN: Dict[CSVColumn, CellValidator] = {
    CSVColumn.C_HGVS: chgvs_validator,
    CSVColumn.P_HGVS: phgvs_validator,
    CSVColumn.G_HGVS: ghgvs_validator,
}

HGVS_NOMENCLATURE_TYPE_BY_COLUMN: Dict[CSVColumn, HgvsNomenclatureType] = {
    CSVColumn.C_HGVS: HgvsNomenclatureType.C_HGVS,
    CSVColumn.P_HGVS: HgvsNomenclatureType.P_HGVS,
    CSVColumn.G_HGVS: HgvsNomenclatureType.G_HGVS,
}


def hgvs_validator(values: Dict[str, str]) -> None:
    """A row validator that checks if the HGVS nomenclatures in a row are valid given a
    transcript.
    """
    if CSVColumn.TRANSCRIPT not in values or not values[CSVColumn.TRANSCRIPT]:
        # Let column validation catch missing transcript column
        return

    transcript = values[CSVColumn.TRANSCRIPT]

    cell_errors = []

    for column in (CSVColumn.C_HGVS, CSVColumn.P_HGVS, CSVColumn.G_HGVS):
        if column not in values or not values[column]:
            # Let column validation catch missing nomenclature column
            continue

        # Skip additional validation if the cell validator for the nomenclature already
        # fails
        value = values[column]
        try:
            HGVS_CELL_VALIDATOR_BY_COLUMN[column](value)
        except CellValidationError:
            continue

        # Validate the HGVS nomenclature more thoroughly using the hgvs library
        nomenclature_type = HGVS_NOMENCLATURE_TYPE_BY_COLUMN[column]
        try:
            if column == CSVColumn.G_HGVS:
                # In the gHGVS case we replace the transcript with NC_ nomenclature. In
                # CSVs submitted to RHP, c. and p. nomenclature simply begins with "c."
                # or "p." with no reference, so we use the transcript column as the
                # reference for those. However, g. nomenclature begins with a
                # Alamut-style reference that looks like "chr17.GRCh37". The hgvs
                # package doesn't recognize this format, so we replace it with the
                # appropriate NC_ reference for the chromosome.
                ghgvs_match = GHGVS_REGEX_OBJECT.match(value)
                # Assertion for mypy - we know there's a match because ghgvs_validator
                # passed using the same regex
                assert ghgvs_match is not None
                chromosome = ghgvs_match.group("chromosome")
                validate_hgvs(
                    nomenclature_type=nomenclature_type,
                    reference=REFERENCES_BY_CHROMOSOME[chromosome.upper()],
                    value=value.split(":")[1],
                )
            else:
                validate_hgvs(
                    nomenclature_type=nomenclature_type,
                    reference=transcript,
                    value=value,
                )
        except CellValidationError as error:
            cell_errors.append(((CSVColumn.TRANSCRIPT, column), error))

    if len(cell_errors) > 0:
        raise RowValidationError.from_errors(cell_errors=cell_errors)


def alleles_list_validator(value: str) -> None:
    """A cell validator that raises `CellValidationError` if the value is not a
    Python-style list of base strings comprised of A, C, T, and G only.

    Args:
        value: The value to validate.
    """
    cell_validation_error = CellValidationError(
        f'invalid allele list "{value}", expected a Python-style list of strings '
        "comprised of A, C, T, and G only (e.g., ['C', 'TG'])"
    )
    try:
        # nosemgrep:semgrep-rules.ast-literal-eval
        parsed_value = ast.literal_eval(value)
    except (ValueError, TypeError, SyntaxError, MemoryError, RecursionError):
        raise cell_validation_error
    base_string_regex = re.compile(BASE_STRING_REGEX)
    if (
        not isinstance(parsed_value, list)
        or not all(isinstance(item, str) for item in parsed_value)
        or not all(base_string_regex.match(item) for item in parsed_value)
    ):
        raise cell_validation_error


def gene_diplotype_and_phenotype_validator(values: Dict[str, str]) -> None:
    """A row validator that checks if the given diplotype and phenotype are valid for the
    given PGx gene.
    """
    if not values.get(CSVColumn.GENE_NAME) or not values.get(CSVColumn.DIPLOTYPE):
        # Let column validation catch missing columns
        return

    gene_name = values[CSVColumn.GENE_NAME]
    if gene_name not in PgxGene.values():
        # Let gene validation catch invalid genes
        return

    gene = PgxGene(gene_name)
    diplotype = values[CSVColumn.DIPLOTYPE]
    if diplotype not in VALID_DIPLOTYPES_AND_PHENOTYPES_BY_PGX_GENE[gene]:
        valid_diplotypes_string = ", ".join(
            sorted(VALID_DIPLOTYPES_AND_PHENOTYPES_BY_PGX_GENE[gene].keys())
        )
        raise RowValidationError.from_errors(
            cell_errors=(
                (
                    (CSVColumn.DIPLOTYPE, CSVColumn.GENE_NAME),
                    CellValidationError(
                        f"invalid diplotype '{diplotype}' for gene {gene_name}, "
                        f"accepted diplotypes are: {valid_diplotypes_string}"
                    ),
                ),
            )
        )

    if not values.get(CSVColumn.PHENOTYPE):
        # Let column validation catch missing columns
        return

    phenotype = values[CSVColumn.PHENOTYPE]
    expected_phenotype = VALID_DIPLOTYPES_AND_PHENOTYPES_BY_PGX_GENE[gene][
        diplotype
    ].value
    if phenotype != expected_phenotype:
        raise RowValidationError.from_errors(
            cell_errors=(
                (
                    (CSVColumn.DIPLOTYPE, CSVColumn.GENE_NAME, CSVColumn.PHENOTYPE),
                    CellValidationError(
                        f"invalid phenotype '{phenotype}' for gene {gene_name} and "
                        f"diplotype {diplotype}, accepted phenotype is "
                        f"{expected_phenotype}"
                    ),
                ),
            )
        )


def classification_write_up_validator(values: Dict[str, str]) -> None:
    """A row validator that, for P/LP variants, checks if the classification write up is
    within the length limit. This is done for report formatting purposes.
    """
    classification = values.get(CSVColumn.CLASSIFICATION)
    if not classification or classification not in Classification.values():
        # Let classification validation catch invalid classifications or missing column
        return

    if not values.get(CSVColumn.CLASSIFICATION_WRITE_UP):
        # Let column validation catch missing columns
        return

    if Classification(classification) not in REPORTABLE_CLASSIFICATIONS:
        # Exempt non-reportable classifications from validation of
        # classification_write_up
        return

    classification_write_up = values[CSVColumn.CLASSIFICATION_WRITE_UP]
    if len(classification_write_up) > CLASSIFICATION_WRITE_UP_LENGTH:
        raise RowValidationError.from_errors(
            cell_errors=(
                (
                    (
                        CSVColumn.CLASSIFICATION,
                        CSVColumn.CLASSIFICATION_WRITE_UP,
                    ),
                    CellValidationError(
                        f"invalid classification write-up length "
                        f"{len(classification_write_up)} - variants with classification "
                        f"'{classification}' must have a classification write-up with "
                        f"length no greater than {CLASSIFICATION_WRITE_UP_LENGTH}"
                    ),
                ),
            )
        )
