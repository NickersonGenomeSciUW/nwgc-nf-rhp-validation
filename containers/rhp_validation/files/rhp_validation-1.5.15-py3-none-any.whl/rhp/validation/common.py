from typing import Dict, Tuple

from rhp.validation.constants import (
    LOW_PENETRANCE_FLAG_TRUE,
    AssayType,
    Classification,
    ClinicalAnalysisType,
    ClinicalValidationLab,
    CSVColumn,
    Disorder,
    GenomeCenter,
    HdrGene,
    ReferenceGenome,
    Sex,
    Zygosity,
)
from rhp.validation.core import CellValidator, RowValidator
from rhp.validation.validators import (
    base_string_validator,
    biobank_id_validator,
    chgvs_validator,
    classification_write_up_validator,
    date_validator,
    gene_and_disorder_validator,
    gene_and_transcript_validator,
    ghgvs_validator,
    hgvs_validator,
    make_optional,
    number_validator,
    options_validator,
    phgvs_validator,
    ref_and_alt_validator,
    refseq_transcript_id_validator,
    required_validator,
    sample_id_validator,
    url_validator,
)

# Store for most cell validators used in this package
SHARED_CELL_VALIDATORS: Dict[CSVColumn, CellValidator] = {
    CSVColumn.BIOBANK_ID: biobank_id_validator,
    CSVColumn.SAMPLE_ID: sample_id_validator,
    CSVColumn.SEX: options_validator(Sex.values()),
    # TODO (@devchakraborty): Maybe validate filenames
    CSVColumn.SEQUENCING_FILE: required_validator,
    CSVColumn.VARIANT_CALL_FILE: required_validator,
    CSVColumn.ASSAY_TYPE: options_validator(AssayType.values()),
    CSVColumn.SEQUENCE_APPROVAL_DATE: date_validator,
    # TODO (@devchakraborty): Maybe validate version numbers
    CSVColumn.REPORTABLE_RANGE_VERSION: required_validator,
    CSVColumn.DRAGEN_PIPELINE_VERSION: required_validator,
    CSVColumn.REVISION_NUMBER: number_validator(min_value=0, integer=True),
    CSVColumn.GENOME_CENTER: options_validator(GenomeCenter.values()),
    CSVColumn.CVL_NAME: options_validator(ClinicalValidationLab.values()),
    # TODO (@devchakraborty): Validate CVL director via allowlist
    CSVColumn.CVL_CLIA_DIRECTOR: required_validator,
    CSVColumn.CHROMOSOME: options_validator(
        ("X", "Y") + tuple(str(i) for i in range(1, 23)),
    ),
    CSVColumn.POSITION: number_validator(min_value=1, integer=True),
    CSVColumn.REFERENCE_GENOME: options_validator(ReferenceGenome.values()),
    CSVColumn.TRANSCRIPT: refseq_transcript_id_validator,
    CSVColumn.G_HGVS: ghgvs_validator,
    CSVColumn.C_HGVS: chgvs_validator,
    CSVColumn.P_HGVS: make_optional(phgvs_validator),
    CSVColumn.ZYGOSITY: options_validator(Zygosity.values()),
    CSVColumn.ALLELE_FRACTION: number_validator(0, 1),
    CSVColumn.PHASING: required_validator,
    CSVColumn.CLASSIFICATION: options_validator(Classification.values()),
    CSVColumn.REPORTED_DISORDER: make_optional(options_validator(Disorder.values())),
    CSVColumn.LOW_PENETRANCE_FLAG: make_optional(
        options_validator((LOW_PENETRANCE_FLAG_TRUE,))
    ),
    CSVColumn.VARIANT_DETAILS: make_optional(url_validator),
}

# Store for HDR-specific cell validators (shared between variant input and HRDF)
HDR_CELL_VALIDATORS: Dict[CSVColumn, CellValidator] = {
    CSVColumn.CLINICAL_ANALYSIS_TYPE: options_validator(
        (ClinicalAnalysisType.HEREDITARY_DISEASE_RISK_V1.value,)
    ),
    CSVColumn.GENE_NAME: options_validator(HdrGene.values()),
    # variant_alt is validated separately between HDR and PGx because its format differs
    # between the two
    CSVColumn.VARIANT_ALT: base_string_validator,
}

# Store for most row validators used in this package
SHARED_ROW_VALIDATORS: Tuple[RowValidator, ...] = (
    gene_and_transcript_validator,
    gene_and_disorder_validator,
    hgvs_validator,
    ref_and_alt_validator,
    classification_write_up_validator,
)
