# Utilities for validating variant files

from typing import Dict, TextIO, Tuple

from rhp.validation.common import (
    HDR_CELL_VALIDATORS,
    SHARED_CELL_VALIDATORS,
    SHARED_ROW_VALIDATORS,
)
from rhp.validation.constants import CSVColumn
from rhp.validation.core import CellValidator, CSVFormat, RowValidator, validate_csv
from rhp.validation.validators import (
    base_string_validator,
    date_validator,
    make_optional,
)

# Columns used in variant input files
VARIANT_INPUT_COLUMNS: Tuple[CSVColumn, ...] = (
    CSVColumn.CVL_NAME,
    CSVColumn.CAID,
    CSVColumn.GENE_NAME,
    CSVColumn.CHROMOSOME,
    CSVColumn.POSITION,
    CSVColumn.VARIANT_REF,
    CSVColumn.VARIANT_ALT,
    CSVColumn.REFERENCE_GENOME,
    CSVColumn.TRANSCRIPT,
    CSVColumn.C_HGVS,
    CSVColumn.P_HGVS,
    CSVColumn.G_HGVS,
    CSVColumn.CLASSIFICATION,
    CSVColumn.REPORTED_DISORDER,
    CSVColumn.LOW_PENETRANCE_FLAG,
    CSVColumn.CLASSIFICATION_WRITE_UP,
    CSVColumn.CLASSIFICATION_DATE,
    CSVColumn.VARIANT_DETAILS,
)

VARIANT_INPUT_CELL_VALIDATORS: Dict[CSVColumn, CellValidator] = {
    **SHARED_CELL_VALIDATORS,
    **HDR_CELL_VALIDATORS,
    # ref, alt, and classification date are optional for variant input files because of
    # historical variants which may not have this information - we require these fields
    # in HRDFs
    CSVColumn.VARIANT_REF: make_optional(base_string_validator),
    CSVColumn.VARIANT_ALT: make_optional(base_string_validator),
    CSVColumn.CLASSIFICATION_DATE: make_optional(date_validator),
}

VARIANT_INPUT_ROW_VALIDATORS: Tuple[RowValidator, ...] = tuple(SHARED_ROW_VALIDATORS)

VARIANT_INPUT_FORMAT = CSVFormat(
    columns=VARIANT_INPUT_COLUMNS,
    cell_validators={
        column.value: validator
        for column, validator in VARIANT_INPUT_CELL_VALIDATORS.items()
    },
    row_validators=VARIANT_INPUT_ROW_VALIDATORS,
)


def validate_variant_input_file(variant_file: TextIO) -> None:
    """Validates a variant input file.

    Args:
        variant_file: The variant input file (any file-like object) to validate.
    """
    validate_csv(variant_file, VARIANT_INPUT_FORMAT)
