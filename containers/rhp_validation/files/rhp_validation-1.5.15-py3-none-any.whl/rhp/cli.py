import sys
from contextlib import contextmanager
from json import dumps as json_dumps
from typing import Generator

import click

from rhp.validation.constants import ClinicalAnalysisType
from rhp.validation.core import CSVValidationError, split_csv
from rhp.validation.hrdf import validate_hdr_hrdf, validate_pgx_hrdf
from rhp.validation.variant_files import (
    VARIANT_INPUT_FORMAT,
    validate_variant_input_file,
)

VALID_ANALYSIS_TYPES = tuple(t.value for t in ClinicalAnalysisType)
VALID_ANALYSIS_TYPES_STRING = ", ".join(f"{t}" for t in VALID_ANALYSIS_TYPES)


def validate_analysis_type(
    ctx: click.Context, param: click.Parameter, analysis_type: str
) -> str:
    if analysis_type.lower() not in (t.lower() for t in VALID_ANALYSIS_TYPES):
        raise click.BadParameter(
            f"Invalid analysis type '{analysis_type}', expected one of: "
            f"{VALID_ANALYSIS_TYPES_STRING}"
        )
    return analysis_type


@click.group()
def cli() -> None:
    pass


@cli.group()
def validate() -> None:
    pass


@validate.command(help="Validate a health-related data file (HRDF)")
@click.option(
    "--analysis-type",
    required=True,
    callback=validate_analysis_type,
    help=f"The clinical analysis type, one of: {VALID_ANALYSIS_TYPES_STRING}",
)
@click.option(
    "--input-file",
    required=True,
    type=click.Path(exists=True, dir_okay=False),
    help="The HRDF CSV file to validate",
)
@click.option(
    "--verbose",
    is_flag=True,
    help="Include this flag to print a detailed cell-by-cell error message",
)
@click.option(
    "--json",
    is_flag=True,
    help=(
        "Include this flag to produce JSON output instead of the default "
        "human-readable message - produces a detailed cell-by-cell output when "
        "combined with --verbose"
    ),
)
def hrdf(
    analysis_type: str, input_file: str, verbose: bool = False, json: bool = False
) -> None:
    with open(input_file) as csv_file:
        with print_validation_result(verbose=verbose, json=json):
            if analysis_type == ClinicalAnalysisType.HEREDITARY_DISEASE_RISK_V1:
                validate_hdr_hrdf(csv_file)
            else:  # PGxV1
                validate_pgx_hrdf(csv_file)


@validate.command(name="variant-input-file", help="Validate a variant input file")
@click.option(
    "--input-file",
    required=True,
    type=click.Path(exists=True, dir_okay=False),
    help="The variant DB input file to validate",
)
@click.option(
    "--verbose",
    is_flag=True,
    help="Include this flag to print a detailed cell-by-cell error message",
)
@click.option(
    "--json",
    is_flag=True,
    help=(
        "Include this flag to produce JSON output instead of the default "
        "human-readable message - produces a detailed cell-by-cell output when "
        "combined with --verbose"
    ),
)
def validate_variant_input_file_command(
    input_file: str, verbose: bool = False, json: bool = False
) -> None:
    with open(input_file) as csv_file:
        with print_validation_result(verbose=verbose, json=json):
            validate_variant_input_file(csv_file)


@contextmanager
def print_validation_result(
    verbose: bool = False, json: bool = False
) -> Generator[None, None, None]:
    """Context manager that prints any CSV validation error encountered to stdout.

    Args:
        verbose: If true, prints a detailed cell-by-cell error message.
        json: TODO
    """
    try:
        yield
        if json:
            print(json_dumps({"valid": True}))
        else:
            print("CSV validation succeeded!")
    except CSVValidationError as error:
        if json:
            print(json_dumps(error.as_dict(verbose=verbose)))
        else:
            print(error.summary(verbose=verbose))
        if not verbose and not json:
            print(
                "\nTo see detailed cell-by-cell errors, run this script with --verbose."
            )
        sys.exit(1)


@cli.group()
def split() -> None:
    pass


@split.command(
    name="variant-input-file",
    help="Split a variant input file into valid and invalid CSVs",
)
@click.option(
    "--input-file",
    required=True,
    type=click.Path(exists=True, dir_okay=False),
    help="The variant DB input file to split",
)
@click.option(
    "--valid-output-file",
    type=click.Path(dir_okay=False),
    help="If provided, the file to write valid rows to",
)
@click.option(
    "--invalid-output-file",
    type=click.Path(dir_okay=False),
    help="If provided, the file to write invalid rows to",
)
def split_variant_input_file(
    input_file: str,
    valid_output_file: str,
    invalid_output_file: str,
) -> None:
    with open(input_file) as csv_file, open(valid_output_file, "w") as valid_file, open(
        invalid_output_file, "w"
    ) as invalid_file:
        split_csv(csv_file, VARIANT_INPUT_FORMAT, valid_file, invalid_file)
